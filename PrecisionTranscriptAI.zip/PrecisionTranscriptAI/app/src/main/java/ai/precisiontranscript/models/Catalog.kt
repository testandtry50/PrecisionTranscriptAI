package ai.precisiontranscript.models

enum class Kind { ASR, ALIGNER, SEGMENTATION, EMBEDDING }
data class RemoteFile(val url: String, val localName: String)
data class ModelEntry(val id: String, val kind: Kind, val title: String, val note: String, val files: List<RemoteFile>)

/** One-tap AI modes: which speech model, and whether to run CTC forced alignment. */
enum class Preset(val label: String, val asrId: String, val accurate: Boolean, val hint: String) {
    FAST("Fast", "whisper-base", false, "Whisper Base, approximate word timing. Quickest."),
    BALANCED("Balanced", "whisper-small", true, "Whisper Small + CTC alignment. Recommended for Hindi and English."),
    BEST("Best", "whisper-medium", true, "Whisper Medium + CTC alignment. Slowest, needs a lot of RAM."),
}

/** Free, openly downloadable models that run fully offline once downloaded. */
object Catalog {
    private fun hf(repo: String, file: String) = "https://huggingface.co/$repo/resolve/main/$file"

    private fun whisper(name: String, note: String): ModelEntry {
        val repo = "csukuangfj/sherpa-onnx-whisper-$name"
        return ModelEntry(
            "whisper-$name", Kind.ASR, "Whisper ${name.replaceFirstChar { it.uppercase() }}", note,
            listOf("$name-encoder.int8.onnx", "$name-decoder.int8.onnx", "$name-tokens.txt").map { RemoteFile(hf(repo, it), it) },
        )
    }

    val asr = listOf(
        whisper("tiny", "~100 MB, fastest, weak on Hindi"),
        whisper("base", "small download, fast, basic Hindi"),
        whisper("small", "~375 MB, good balance, usable Hindi"),
        whisper("medium", "large download, most accurate, slow"),
    )

    val aligners = listOf(
        ModelEntry("align-en", Kind.ALIGNER, "English aligner (wav2vec2-base-960h)", "~360 MB, English only", listOf(
            RemoteFile(hf("ysdede/wav2vec2-base-960h-onnx", "model.onnx"), "model.onnx"),
            RemoteFile(hf("ysdede/wav2vec2-base-960h-onnx", "model.onnx.data"), "model.onnx.data"),
            RemoteFile(hf("ysdede/wav2vec2-base-960h-onnx", "vocab.json"), "vocab.json"),
        )),
        ModelEntry("align-hi", Kind.ALIGNER, "Hindi aligner (Vakyansh wav2vec2)", "Hindi, community ONNX export, MIT", listOf(
            RemoteFile(hf("madhushripatil032003/readnet-onnx", "hi.onnx"), "model.onnx"),
            RemoteFile(hf("madhushripatil032003/readnet-onnx", "vocab_hi.json"), "vocab.json"),
        )),
    )

    val speaker = listOf(
        ModelEntry("seg-pyannote", Kind.SEGMENTATION, "Speaker segmentation (pyannote 3.0)", "~6 MB", listOf(
            RemoteFile(hf("csukuangfj/sherpa-onnx-pyannote-segmentation-3-0", "model.onnx"), "model.onnx"))),
        ModelEntry("emb-titanet", Kind.EMBEDDING, "Speaker embedding (NeMo TitaNet large)", "~97 MB", listOf(
            RemoteFile(hf("csukuangfj/speaker-embedding-models", "nemo_en_titanet_large.onnx"), "model.onnx"))),
    )

    /** Whisper language codes. Only Hindi and English have a word-alignment model; others get approximate word timing. */
    val languages = listOf(
        "Hindi" to "hi", "English" to "en", "Auto-detect" to "", "Bengali" to "bn", "Tamil" to "ta", "Telugu" to "te",
        "Marathi" to "mr", "Gujarati" to "gu", "Punjabi" to "pa", "Urdu" to "ur", "Spanish" to "es", "French" to "fr",
        "German" to "de", "Arabic" to "ar", "Portuguese" to "pt", "Russian" to "ru", "Japanese" to "ja", "Korean" to "ko", "Chinese" to "zh",
    )

    val all = asr + aligners + speaker
    fun byId(id: String) = all.first { it.id == id }
    fun alignerFor(lang: String): String? = when (lang) { "en" -> "align-en"; "hi" -> "align-hi"; else -> null }
}
