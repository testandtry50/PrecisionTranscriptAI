package ai.precisiontranscript.ui

import ai.precisiontranscript.Prefs
import ai.precisiontranscript.models.ModelEntry
import ai.precisiontranscript.models.ModelStore
import ai.precisiontranscript.player.PlayerController
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    prefs: Prefs, store: ModelStore, player: PlayerController, models: List<ModelEntry>, busy: Boolean,
    onDelete: (ModelEntry) -> Unit, onBack: () -> Unit,
) {
    var preRoll by remember { mutableIntStateOf(prefs.preRollMs) }
    var awake by remember { mutableStateOf(prefs.keepAwake) }
    Scaffold { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← Back") }
                Text("Settings", style = MaterialTheme.typography.titleLarge)
            }

            Text("Tap-to-play pre-roll", style = MaterialTheme.typography.labelLarge)
            Text("Start playback a little before the tapped word so you hear its first sound.", style = MaterialTheme.typography.bodySmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0, 250, 500, 1000).forEach { ms ->
                    FilterChip(
                        selected = preRoll == ms,
                        onClick = { preRoll = ms; prefs.preRollMs = ms; player.preRollUs = ms * 1000L },
                        label = { Text(if (ms == 0) "Off" else "$ms ms") },
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Keep the screen on while transcribing or downloading", Modifier.weight(1f))
                Switch(checked = awake, onCheckedChange = { awake = it; prefs.keepAwake = it })
            }

            Text("Models on this phone", style = MaterialTheme.typography.titleMedium)
            if (models.isEmpty()) Text("None downloaded yet.", style = MaterialTheme.typography.bodySmall)
            models.forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.title, style = MaterialTheme.typography.bodySmall)
                        Text("${store.sizeBytes(m) / 1_000_000} MB", style = MaterialTheme.typography.labelSmall)
                    }
                    TextButton(enabled = !busy, onClick = { onDelete(m) }) { Text("Delete") }
                }
            }
            if (models.isNotEmpty()) Text("Total: ${models.sumOf { store.sizeBytes(it) } / 1_000_000} MB", style = MaterialTheme.typography.labelMedium)

            Text("Privacy", style = MaterialTheme.typography.titleMedium)
            Text("Audio, transcripts and projects stay on this phone. The internet is used only to download the models you choose.",
                style = MaterialTheme.typography.bodySmall)
        }
    }
}
