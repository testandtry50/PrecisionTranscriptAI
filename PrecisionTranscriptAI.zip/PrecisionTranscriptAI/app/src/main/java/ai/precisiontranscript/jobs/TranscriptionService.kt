package ai.precisiontranscript.jobs

import ai.precisiontranscript.MainActivity
import ai.precisiontranscript.models.ModelStore
import ai.precisiontranscript.project.ProjectDb
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

/**
 * Runs the transcription queue one project at a time, in a foreground service with a partial wake lock, so it keeps
 * going with the screen off or the app closed. Jobs are checkpointed; if Android stops the service they resume later.
 * (One at a time on purpose: two Whisper models at once would double the memory use on a phone.)
 */
class TranscriptionService : Service() {
    companion object {
        private const val CHANNEL = "transcription"
        private const val NOTIF_ID = 41
        private const val DONE_ID = 42
        private const val ACTION_STOP = "ai.precisiontranscript.STOP"
        @Volatile private var current: Job? = null
        @Volatile private var cancelId = -1L

        /** Cancels a running job (the service finishes cleanly and moves on to the next one). */
        fun cancel(id: Long) { cancelId = id; current?.cancel() }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var worker: Job? = null
    private var wake: PowerManager.WakeLock? = null
    private var lastPct = -1
    private var lastStage = ""
    private var lastStartId = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Transcription", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastStartId = startId
        if (intent?.action == ACTION_STOP) {          // "Pause queue": jobs stay queued and resume from their checkpoints
            worker?.cancel(); stopSelf(); return START_NOT_STICKY
        }
        try {
            val n = notification("Starting…", 0)
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(NOTIF_ID, n)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }     // e.g. Android refused a background start
        if (worker?.isActive != true) worker = scope.launch { runQueue() }
        return START_STICKY
    }

    /** Android 15 limits data-sync services to about 6 hours a day. Stop cleanly; the user resumes from the app. */
    override fun onTimeout(startId: Int, fgsType: Int) { worker?.cancel(); stopSelf() }

    override fun onDestroy() {
        scope.cancel()
        wake?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    private suspend fun runQueue() {
        val db = ProjectDb.get(applicationContext)
        val runner = JobRunner(applicationContext, db, ModelStore(applicationContext))
        wake = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "precisiontranscript:queue").also { it.acquire(6 * 60 * 60 * 1000L) }
        var finished = 0
        try {
            db.requeueRunning()
            while (true) {
                val spec = db.nextQueued() ?: break
                db.setStatus(spec.id, JobStatus.RUNNING, "Starting", "")
                lastPct = -1; lastStage = ""
                coroutineScope {
                    val j = launch { runOne(db, runner, spec) }
                    current = j
                    j.join()
                }
                if (db.statusOf(spec.id) == JobStatus.DONE) finished++
            }
        } finally {
            current = null
            wake?.takeIf { it.isHeld }?.release()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        if (finished > 0) notifyDone(finished)
        stopSelf(lastStartId)
    }

    private suspend fun runOne(db: ProjectDb, runner: JobRunner, spec: JobSpec) {
        try {
            val pid = runner.run(spec) { stage, p -> publish(db, spec, stage, p) }
            db.finishJob(spec.id, pid)
        } catch (e: CancellationException) {
            if (cancelId == spec.id) { db.setStatus(spec.id, JobStatus.CANCELLED, "Cancelled", ""); runner.discard(spec.id) }
            throw e                    // otherwise the service is stopping: the job stays RUNNING and resumes next time
        } catch (e: Throwable) {
            db.setStatus(spec.id, JobStatus.FAILED, "", e.message ?: e.javaClass.simpleName)
        }
    }

    private fun publish(db: ProjectDb, spec: JobSpec, stage: String, p: Float) {
        val pct = (p * 100).toInt()
        if (pct == lastPct && stage == lastStage) return
        lastPct = pct; lastStage = stage
        db.setProgress(spec.id, stage, p)
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification("${spec.title}: $stage", pct))
    }

    private fun notification(text: String, pct: Int): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, TranscriptionService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Precision Transcript AI")
            .setContentText(text)
            .setOnlyAlertOnce(true).setOngoing(true)
            .setProgress(100, pct, pct <= 0)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Pause queue", stop).build())
            .build()
    }

    private fun notifyDone(n: Int) {
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val nt = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Transcription finished").setContentText("$n project(s) ready")
            .setContentIntent(open).setAutoCancel(true).build()
        getSystemService(NotificationManager::class.java).notify(DONE_ID, nt)
    }
}
