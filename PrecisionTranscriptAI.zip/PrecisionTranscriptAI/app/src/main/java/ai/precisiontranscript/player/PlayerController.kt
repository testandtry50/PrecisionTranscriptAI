package ai.precisiontranscript.player

import ai.precisiontranscript.core.usToMsCeil
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/** Media3 wrapper. Main thread only. Call [tick] regularly: Media3 does not push position updates. */
class PlayerController(ctx: Context) : AutoCloseable {
    private val exo: ExoPlayer = ExoPlayer.Builder(ctx).build()

    init {
        // audio only: the video track is never decoded
        exo.trackSelectionParameters = exo.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
            .build()
    }

    var positionUs by mutableLongStateOf(0L)
        private set
    var durationUs by mutableLongStateOf(0L)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var speed by mutableFloatStateOf(1f)
        private set

    private var stopAtUs = -1L

    /** Tap-to-play starts this much before the tapped word (set from Settings). */
    var preRollUs = 0L

    fun load(uri: Uri) {
        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.prepare()
        tick()
    }

    fun tick() {
        positionUs = exo.currentPosition * 1000L
        isPlaying = exo.isPlaying
        val d = exo.duration
        if (d != C.TIME_UNSET) durationUs = d * 1000L
        if (stopAtUs >= 0L && positionUs >= stopAtUs) {
            exo.pause()
            stopAtUs = -1L
            isPlaying = false
        }
    }

    fun toggle() {
        stopAtUs = -1L
        if (exo.isPlaying) {
            exo.pause()
        } else {
            if (exo.playbackState == Player.STATE_ENDED) exo.seekTo(0L)
            exo.play()
        }
        tick()
    }

    fun pause() {
        exo.pause()
        tick()
    }

    fun stop() {
        exo.pause()
        exo.seekTo(0L)
        stopAtUs = -1L
        tick()
    }

    fun skipMs(delta: Long) {
        val d = exo.duration
        val end = if (d == C.TIME_UNSET) Long.MAX_VALUE else d
        stopAtUs = -1L
        exo.seekTo((exo.currentPosition + delta).coerceIn(0L, end))
        tick()
    }

    /** Tap-to-seek. Resolution is 1 ms (Media3 limit); the timestamps themselves stay in microseconds. */
    fun seekToUs(us: Long, play: Boolean = true) {
        stopAtUs = -1L
        exo.seekTo(us.usToMsCeil())
        if (play) exo.play()
        tick()
    }

    /** Plays one sentence and pauses at its end. */
    fun playRange(startUs: Long, endUs: Long) {
        seekToUs(startUs)
        stopAtUs = endUs
    }

    fun setSpeed(s: Float) {
        exo.setPlaybackSpeed(s)
        speed = s
    }

    override fun close() {
        exo.release()
    }
}
