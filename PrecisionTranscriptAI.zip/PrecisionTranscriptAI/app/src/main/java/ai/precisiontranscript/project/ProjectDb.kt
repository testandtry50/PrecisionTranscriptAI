package ai.precisiontranscript.project

import ai.precisiontranscript.core.Doc
import ai.precisiontranscript.core.Original
import ai.precisiontranscript.core.State
import ai.precisiontranscript.core.Word
import ai.precisiontranscript.core.WordDiff
import ai.precisiontranscript.jobs.JobInfo
import ai.precisiontranscript.jobs.JobSpec
import ai.precisiontranscript.jobs.JobStatus
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class ProjectInfo(val id: Long, val title: String, val updatedMs: Long)
data class Loaded(val id: Long, val title: String, val uri: String, val warnings: List<String>, val doc: Doc)

/**
 * Plain SQLite (one shared instance, WAL, so the background service and the UI can use it at the same time).
 * Times are INTEGER microseconds. `word` = current words, `orig` = original transcription (both keyed by stable word id).
 * Job tables hold the background queue and per-chunk checkpoints so a long transcription can resume after the app is killed.
 */
class ProjectDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "projects.db", null, 4) {
    companion object {
        @Volatile private var inst: ProjectDb? = null
        fun get(ctx: Context): ProjectDb = inst ?: synchronized(this) { inst ?: ProjectDb(ctx.applicationContext).also { inst = it } }
    }

    private fun wordDdl(t: String) =
        "CREATE TABLE $t(project_id INTEGER, id INTEGER, pos INTEGER, text TEXT, start_us INTEGER, end_us INTEGER, speaker INTEGER, PRIMARY KEY(project_id, id))"

    private fun jobTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS job(id INTEGER PRIMARY KEY AUTOINCREMENT, uri TEXT, title TEXT, lang TEXT, asr_id TEXT, " +
            "accurate INTEGER, speakers INTEGER, status TEXT, stage TEXT, progress REAL, error TEXT, project_id INTEGER, decoded INTEGER, created_ms INTEGER)")
        db.execSQL("CREATE TABLE IF NOT EXISTS chunk(job_id INTEGER, idx INTEGER, approx INTEGER, PRIMARY KEY(job_id, idx))")
        db.execSQL("CREATE TABLE IF NOT EXISTS chunk_word(job_id INTEGER, idx INTEGER, pos INTEGER, text TEXT, start_us INTEGER, end_us INTEGER)")
        db.execSQL("CREATE INDEX IF NOT EXISTS chunk_word_ix ON chunk_word(job_id, idx, pos)")
    }

    override fun onConfigure(db: SQLiteDatabase) { db.enableWriteAheadLogging() }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE project(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, uri TEXT, warnings TEXT, updated_ms INTEGER)")
        db.execSQL(wordDdl("word")); db.execSQL(wordDdl("orig"))
        db.execSQL("CREATE TABLE mark(project_id INTEGER, kind TEXT, idx INTEGER)")
        db.execSQL("CREATE TABLE speaker(project_id INTEGER, id INTEGER, name TEXT)")
        jobTables(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("CREATE TABLE IF NOT EXISTS speaker(project_id INTEGER, id INTEGER, name TEXT)")
        if (oldVersion < 3) {   // old rows: id = idx, original stored inline in o_* columns
            db.execSQL(wordDdl("orig"))
            db.execSQL("INSERT INTO orig SELECT project_id, idx, idx, o_text, o_start_us, o_end_us, o_speaker FROM word")
            db.execSQL(wordDdl("word_new"))
            db.execSQL("INSERT INTO word_new SELECT project_id, idx, idx, text, start_us, end_us, speaker FROM word")
            db.execSQL("DROP TABLE word")
            db.execSQL("ALTER TABLE word_new RENAME TO word")
        }
        if (oldVersion < 4) jobTables(db)
    }

    // ---------------------------------------------------------------- projects

    private fun insertWords(db: SQLiteDatabase, table: String, pid: Long, words: List<Word>) {
        val st = db.compileStatement("INSERT INTO $table VALUES(?,?,?,?,?,?,?)")
        words.forEachIndexed { pos, w ->
            st.clearBindings()
            st.bindLong(1, pid); st.bindLong(2, w.id.toLong()); st.bindLong(3, pos.toLong()); st.bindString(4, w.text)
            st.bindLong(5, w.startUs); st.bindLong(6, w.endUs); st.bindLong(7, w.speaker.toLong())
            st.executeInsert()
        }
        st.close()
    }

    private fun updateWords(db: SQLiteDatabase, pid: Long, words: List<Word>, indices: List<Int>) {
        val st = db.compileStatement("UPDATE word SET text=?, start_us=?, end_us=?, speaker=? WHERE project_id=? AND id=?")
        for (i in indices) {
            val w = words[i]
            st.clearBindings()
            st.bindString(1, w.text); st.bindLong(2, w.startUs); st.bindLong(3, w.endUs); st.bindLong(4, w.speaker.toLong())
            st.bindLong(5, pid); st.bindLong(6, w.id.toLong())
            st.executeUpdateDelete()
        }
        st.close()
    }

    private fun readWords(db: SQLiteDatabase, table: String, arg: Array<String>): List<Word> =
        db.rawQuery("SELECT id,text,start_us,end_us,speaker FROM $table WHERE project_id=? ORDER BY pos", arg).use { c ->
            buildList { while (c.moveToNext()) add(Word(c.getString(1) ?: "", c.getLong(2), c.getLong(3), c.getInt(4), c.getInt(0))) }
        }

    /**
     * Saves a project. The original words are written only when the project is created. When [prevWords] (what the last
     * save wrote) has the same word ids in the same order, only the changed rows are updated: an edit in a 5-hour
     * transcript (~45,000 words) then costs a few row updates instead of rewriting everything.
     */
    fun save(id: Long?, title: String, uri: String, warnings: List<String>, doc: Doc, prevWords: List<Word>? = null): Long {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val cv = ContentValues().apply {
                put("title", title); put("uri", uri); put("warnings", warnings.joinToString("\n")); put("updated_ms", System.currentTimeMillis())
            }
            val pid: Long
            var isNew = true
            if (id != null && db.update("project", cv, "id=?", arrayOf(id.toString())) > 0) { pid = id; isNew = false }
            else pid = db.insertOrThrow("project", null, cv)
            val arg = arrayOf(pid.toString())

            val diff = if (!isNew && prevWords != null) WordDiff.changed(prevWords, doc.words) else null
            if (diff != null) updateWords(db, pid, doc.words, diff)
            else { db.delete("word", "project_id=?", arg); insertWords(db, "word", pid, doc.words) }
            if (isNew) insertWords(db, "orig", pid, doc.original.words)

            for (t in listOf("mark", "speaker")) db.delete(t, "project_id=?", arg)
            doc.state.cuts.forEach { db.execSQL("INSERT INTO mark VALUES(?,?,?)", arrayOf<Any>(pid, "cut", it)) }
            doc.state.joins.forEach { db.execSQL("INSERT INTO mark VALUES(?,?,?)", arrayOf<Any>(pid, "join", it)) }
            doc.state.names.forEach { (k, v) -> db.execSQL("INSERT INTO speaker VALUES(?,?,?)", arrayOf<Any>(pid, k, v)) }
            db.setTransactionSuccessful()
            return pid
        } finally { db.endTransaction() }
    }

    fun list(): List<ProjectInfo> =
        readableDatabase.rawQuery("SELECT id,title,updated_ms FROM project ORDER BY updated_ms DESC", null).use { c ->
            buildList { while (c.moveToNext()) add(ProjectInfo(c.getLong(0), c.getString(1) ?: "", c.getLong(2))) }
        }

    fun load(id: Long): Loaded? {
        val db = readableDatabase
        val arg = arrayOf(id.toString())
        return db.rawQuery("SELECT title,uri,warnings FROM project WHERE id=?", arg).use { c ->
            if (!c.moveToFirst()) return@use null
            val words = readWords(db, "word", arg)
            val orig = readWords(db, "orig", arg)
            val cuts = HashSet<Int>(); val joins = HashSet<Int>()
            db.rawQuery("SELECT kind,idx FROM mark WHERE project_id=?", arg).use { m ->
                while (m.moveToNext()) (if (m.getString(0) == "cut") cuts else joins).add(m.getInt(1))
            }
            val names = HashMap<Int, String>()
            db.rawQuery("SELECT id,name FROM speaker WHERE project_id=?", arg).use { n ->
                while (n.moveToNext()) names[n.getInt(0)] = n.getString(1) ?: ""
            }
            val warn = (c.getString(2) ?: "").split("\n").filter { it.isNotBlank() }
            Loaded(id, c.getString(0) ?: "", c.getString(1) ?: "", warn, Doc(Original(orig), State(words, cuts, joins, names)))
        }
    }

    fun remove(id: Long) {
        val db = writableDatabase
        val arg = arrayOf(id.toString())
        for (t in listOf("word", "orig", "mark", "speaker")) db.delete(t, "project_id=?", arg)
        db.delete("project", "id=?", arrayOf(id.toString()))
    }

    // ---------------------------------------------------------------- background queue

    private fun specFrom(c: Cursor) =
        JobSpec(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "", c.getString(4) ?: "", c.getInt(5) == 1, c.getInt(6) == 1)

    private val jobCols = "id,uri,title,lang,asr_id,accurate,speakers"

    fun enqueue(uri: String, title: String, lang: String, asrId: String, accurate: Boolean, speakers: Boolean): Long {
        val cv = ContentValues().apply {
            put("uri", uri); put("title", title); put("lang", lang); put("asr_id", asrId)
            put("accurate", if (accurate) 1 else 0); put("speakers", if (speakers) 1 else 0)
            put("status", JobStatus.QUEUED.name); put("stage", "Waiting"); put("progress", 0.0); put("error", "")
            put("decoded", 0); put("created_ms", System.currentTimeMillis())
        }
        return writableDatabase.insertOrThrow("job", null, cv)
    }

    fun jobs(): List<JobInfo> =
        readableDatabase.rawQuery("SELECT $jobCols,status,stage,progress,error,project_id FROM job ORDER BY id", null).use { c ->
            buildList {
                while (c.moveToNext()) add(JobInfo(
                    specFrom(c), JobStatus.valueOf(c.getString(7)), c.getString(8) ?: "", c.getFloat(9), c.getString(10) ?: "",
                    if (c.isNull(11)) null else c.getLong(11),
                ))
            }
        }

    fun nextQueued(): JobSpec? =
        readableDatabase.rawQuery("SELECT $jobCols FROM job WHERE status='QUEUED' ORDER BY id LIMIT 1", null).use { c ->
            if (c.moveToFirst()) specFrom(c) else null
        }

    fun statusOf(id: Long): JobStatus? =
        readableDatabase.rawQuery("SELECT status FROM job WHERE id=?", arrayOf(id.toString())).use { c ->
            if (c.moveToFirst()) JobStatus.valueOf(c.getString(0)) else null
        }

    fun setStatus(id: Long, status: JobStatus, stage: String, error: String) {
        val cv = ContentValues().apply { put("status", status.name); put("stage", stage); put("error", error) }
        writableDatabase.update("job", cv, "id=?", arrayOf(id.toString()))
    }

    fun setProgress(id: Long, stage: String, progress: Float) {
        val cv = ContentValues().apply { put("stage", stage); put("progress", progress.toDouble()) }
        writableDatabase.update("job", cv, "id=? AND status='RUNNING'", arrayOf(id.toString()))
    }

    fun finishJob(id: Long, projectId: Long) {
        val cv = ContentValues().apply { put("status", JobStatus.DONE.name); put("stage", "Done"); put("progress", 1.0); put("project_id", projectId) }
        writableDatabase.update("job", cv, "id=?", arrayOf(id.toString()))
    }

    /** After the app or service was killed: jobs that were running go back to the queue and resume from their checkpoints. */
    fun requeueRunning() {
        val cv = ContentValues().apply { put("status", JobStatus.QUEUED.name); put("stage", "Waiting (resuming)") }
        writableDatabase.update("job", cv, "status='RUNNING'", null)
    }

    fun retry(id: Long) = setStatus(id, JobStatus.QUEUED, "Waiting", "")

    fun isDecoded(id: Long): Boolean =
        readableDatabase.rawQuery("SELECT decoded FROM job WHERE id=?", arrayOf(id.toString())).use { c -> c.moveToFirst() && c.getInt(0) == 1 }

    fun markDecoded(id: Long) {
        writableDatabase.update("job", ContentValues().apply { put("decoded", 1) }, "id=?", arrayOf(id.toString()))
    }

    fun clearChunks(id: Long) {
        val db = writableDatabase
        val arg = arrayOf(id.toString())
        db.delete("chunk", "job_id=?", arg); db.delete("chunk_word", "job_id=?", arg)
    }

    fun removeJob(id: Long) { clearChunks(id); writableDatabase.delete("job", "id=?", arrayOf(id.toString())) }

    fun completedChunks(id: Long): Set<Int> =
        readableDatabase.rawQuery("SELECT idx FROM chunk WHERE job_id=?", arrayOf(id.toString())).use { c ->
            buildSet { while (c.moveToNext()) add(c.getInt(0)) }
        }

    /** One transaction per finished chunk: the words and the "done" marker are saved together. */
    fun saveChunk(jobId: Long, idx: Int, words: List<Word>, approx: Boolean) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val arg = arrayOf(jobId.toString(), idx.toString())
            db.delete("chunk_word", "job_id=? AND idx=?", arg)
            val st = db.compileStatement("INSERT INTO chunk_word VALUES(?,?,?,?,?,?)")
            words.forEachIndexed { pos, w ->
                st.clearBindings()
                st.bindLong(1, jobId); st.bindLong(2, idx.toLong()); st.bindLong(3, pos.toLong())
                st.bindString(4, w.text); st.bindLong(5, w.startUs); st.bindLong(6, w.endUs)
                st.executeInsert()
            }
            st.close()
            db.execSQL("INSERT OR REPLACE INTO chunk VALUES(?,?,?)", arrayOf<Any>(jobId, idx, if (approx) 1 else 0))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun chunkWords(jobId: Long): List<Word> =
        readableDatabase.rawQuery("SELECT text,start_us,end_us FROM chunk_word WHERE job_id=? ORDER BY idx,pos", arrayOf(jobId.toString())).use { c ->
            buildList { while (c.moveToNext()) add(Word(c.getString(0) ?: "", c.getLong(1), c.getLong(2))) }
        }

    fun approxChunks(jobId: Long): Int =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM chunk WHERE job_id=? AND approx=1", arrayOf(jobId.toString())).use { c ->
            if (c.moveToFirst()) c.getInt(0) else 0
        }
}
