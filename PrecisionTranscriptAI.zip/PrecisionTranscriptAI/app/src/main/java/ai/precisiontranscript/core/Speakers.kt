package ai.precisiontranscript.core

data class SpeakerSegment(val startUs: Long, val endUs: Long, val speaker: Int)

object Speakers {
    /**
     * Each word gets the speaker whose segment overlaps it most. Words that overlap no segment inherit the previous
     * word's speaker (leading ones take the first known speaker).
     */
    fun assign(words: List<Word>, segments: List<SpeakerSegment>): List<Word> {
        if (segments.isEmpty()) return words
        val segs = segments.sortedBy { it.startUs }
        val raw = IntArray(words.size) { -1 }
        for ((i, w) in words.withIndex()) {
            var best = 0L
            for (s in segs) {
                if (s.startUs >= w.endUs) break
                val ov = minOf(w.endUs, s.endUs) - maxOf(w.startUs, s.startUs)
                if (ov > best) { best = ov; raw[i] = s.speaker }
            }
        }
        var last = raw.firstOrNull { it >= 0 } ?: return words
        for (i in raw.indices) { if (raw[i] >= 0) last = raw[i] else raw[i] = last }
        return words.mapIndexed { i, w -> w.copy(speaker = raw[i]) }
    }
}

data class SpeakerWindow(val start: Long, val end: Long, val keepFrom: Long, val keepTo: Long)

/** Speaker identification for recordings too long to hold in memory: overlapping windows, labels matched by overlap. */
object SpeakerStitch {
    private const val MIN_MATCH_US = 1_000_000L      // at least 1 s of shared speech to call two labels the same person

    fun plan(total: Long, window: Long, overlap: Long): List<SpeakerWindow> {
        val out = ArrayList<SpeakerWindow>()
        var start = 0L; var keepFrom = 0L
        while (true) {
            val end = minOf(start + window, total)
            if (end >= total) { out.add(SpeakerWindow(start, total, keepFrom, total)); return out }
            val next = end - overlap
            val mid = (next + end) / 2
            out.add(SpeakerWindow(start, end, keepFrom, mid)); keepFrom = mid; start = next
        }
    }

    /**
     * Maps the speaker ids of [cur] (a new window) onto the ids in [known] (earlier windows) using how much they
     * talk at the same time inside the shared region [overlapStart, overlapEnd]. Unmatched speakers get new ids.
     * Returns the relabelled segments and the next unused id.
     */
    fun relabel(known: List<SpeakerSegment>, cur: List<SpeakerSegment>, overlapStart: Long, overlapEnd: Long, nextId: Int): Pair<List<SpeakerSegment>, Int> {
        val score = HashMap<Pair<Int, Int>, Long>()
        for (c in cur) for (k in known) {
            val ov = minOf(c.endUs, k.endUs, overlapEnd) - maxOf(c.startUs, k.startUs, overlapStart)
            if (ov > 0) { val key = c.speaker to k.speaker; score[key] = (score[key] ?: 0L) + ov }
        }
        val map = HashMap<Int, Int>(); val used = HashSet<Int>()
        for (e in score.entries.sortedByDescending { it.value }) {
            if (e.value < MIN_MATCH_US) break
            if (e.key.first in map || e.key.second in used) continue
            map[e.key.first] = e.key.second; used.add(e.key.second)
        }
        var next = nextId
        val out = cur.map { c -> c.copy(speaker = map.getOrPut(c.speaker) { next++ }) }
        return out to next
    }

    fun clip(segs: List<SpeakerSegment>, from: Long, to: Long): List<SpeakerSegment> = segs.mapNotNull {
        val s = maxOf(it.startUs, from); val e = minOf(it.endUs, to)
        if (e > s) it.copy(startUs = s, endUs = e) else null
    }
}
