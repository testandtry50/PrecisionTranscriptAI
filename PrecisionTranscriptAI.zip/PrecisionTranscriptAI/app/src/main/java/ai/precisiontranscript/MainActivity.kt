package ai.precisiontranscript

import ai.precisiontranscript.core.Doc
import ai.precisiontranscript.core.ExportFormat
import ai.precisiontranscript.core.Word
import ai.precisiontranscript.jobs.JobInfo
import ai.precisiontranscript.jobs.JobStatus
import ai.precisiontranscript.jobs.TranscriptionService
import ai.precisiontranscript.models.Catalog
import ai.precisiontranscript.models.ModelStore
import ai.precisiontranscript.models.Preset
import ai.precisiontranscript.player.PlayerController
import ai.precisiontranscript.project.ProjectDb
import ai.precisiontranscript.project.ProjectInfo
import ai.precisiontranscript.ui.EditorScreen
import ai.precisiontranscript.ui.JobRow
import ai.precisiontranscript.ui.SettingsScreen
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private lateinit var player: PlayerController
    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(applicationContext)
        player = PlayerController(applicationContext)
        player.preRollUs = prefs.preRollMs * 1000L
        setContent { MaterialTheme { Root() } }
    }

    override fun onStop() { player.pause(); super.onStop() }
    override fun onDestroy() { player.close(); super.onDestroy() }

    private fun startQueue() = startForegroundService(Intent(this, TranscriptionService::class.java))

    private fun nameOf(u: Uri): String =
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: u.lastPathSegment ?: "Untitled"

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun Root() {
        val scope = rememberCoroutineScope()
        val store = remember { ModelStore(applicationContext) }
        val db = remember { ProjectDb.get(applicationContext) }
        var picked by remember { mutableStateOf<List<Uri>>(emptyList()) }
        var uri by remember { mutableStateOf<Uri?>(null) }              // source of the open project, for playback
        var title by remember { mutableStateOf("") }
        var lang by remember { mutableStateOf(prefs.lang) }
        var asrId by remember { mutableStateOf(prefs.asrId) }
        var accurate by remember { mutableStateOf(prefs.accurate) }
        var speakers by remember { mutableStateOf(prefs.speakers) }
        var busy by remember { mutableStateOf(false) }                  // model download in progress
        var status by remember { mutableStateOf("") }
        var progress by remember { mutableStateOf(0f) }
        var doc by remember { mutableStateOf<Doc?>(null) }
        var warnings by remember { mutableStateOf<List<String>>(emptyList()) }
        var projectId by remember { mutableStateOf<Long?>(null) }
        var lastSaved by remember { mutableStateOf<List<Word>?>(null) }
        var saveNote by remember { mutableStateOf("") }
        var projects by remember { mutableStateOf<List<ProjectInfo>>(emptyList()) }
        var jobs by remember { mutableStateOf<List<JobInfo>>(emptyList()) }
        var rev by remember { mutableIntStateOf(0) }
        var pending by remember { mutableStateOf<ExportFormat?>(null) }
        var dl by remember { mutableStateOf<Job?>(null) }
        var settings by remember { mutableStateOf(false) }

        // Media3 pushes no position updates: poll once per frame while playing, slowly otherwise.
        LaunchedEffect(Unit) {
            while (true) { if (player.isPlaying) withFrameNanos { } else delay(200); player.tick() }
        }
        // The queue runs in a service; the screen just watches the database.
        LaunchedEffect(Unit) {
            while (true) {
                val (j, p) = withContext(Dispatchers.IO) { db.jobs() to db.list() }
                jobs = j; projects = p
                delay(1000)
            }
        }
        LaunchedEffect(uri) { uri?.let { runCatching { player.load(it) } } }
        LaunchedEffect(lang, asrId, accurate, speakers) { prefs.lang = lang; prefs.asrId = asrId; prefs.accurate = accurate; prefs.speakers = speakers }
        LaunchedEffect(busy) {   // downloads: keep the screen on
            if (busy && prefs.keepAwake) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        // Autosave 1.5 s after the last edit. Only changed words are written (see ProjectDb.save).
        LaunchedEffect(doc) {
            val d = doc ?: return@LaunchedEffect
            saveNote = "Saving…"
            delay(1500)
            val prev = lastSaved
            projectId = withContext(Dispatchers.IO) { db.save(projectId, title.ifBlank { "Untitled" }, uri?.toString() ?: "", warnings, d, prev) }
            lastSaved = d.words
            saveNote = "Saved"
        }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
            list.forEach { u -> runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
            picked = list
        }
        val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
        val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { dest ->
            val f = pending; val d = doc
            if (dest != null && f != null && d != null)   // exports always derive sentences from the current words
                contentResolver.openOutputStream(dest)?.use { it.write(f.render(d.toTranscript()).toByteArray()) }
        }

        val openProject: (Long) -> Unit = { id ->
            scope.launch {
                val l = withContext(Dispatchers.IO) { db.load(id) }
                if (l != null) {
                    uri = l.uri.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
                    title = l.title; warnings = l.warnings; projectId = l.id; lastSaved = l.doc.words; doc = l.doc
                }
            }
        }

        val d = doc
        if (d != null) {
            EditorScreen(d, warnings, saveNote, player, onDoc = { doc = it },
                onNew = { player.stop(); doc = null; projectId = null; lastSaved = null },
                onExport = { f -> pending = f; saver.launch("transcript.${f.ext}") })
            return
        }

        val needed = remember(asrId, accurate, lang, speakers) {
            buildList {
                add(Catalog.byId(asrId))
                if (accurate) Catalog.alignerFor(lang)?.let { add(Catalog.byId(it)) }
                if (speakers) { add(Catalog.byId("seg-pyannote")); add(Catalog.byId("emb-titanet")) }
            }
        }
        val missing = remember(needed, rev) { needed.filter { !store.installed(it) } }
        val installed = remember(rev) { Catalog.all.filter { store.installed(it) } }
        val queueActive = jobs.any { it.status == JobStatus.QUEUED || it.status == JobStatus.RUNNING }

        if (settings) {
            SettingsScreen(prefs, store, player, installed, busy || queueActive, onDelete = { store.delete(it); rev++ }, onBack = { settings = false })
            return
        }

        Scaffold { pad ->
            Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Precision Transcript AI", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = { settings = true }) { Text("Settings") }
                }
                OutlinedButton(onClick = { picker.launch(arrayOf("audio/*", "video/*")) }) {
                    Text(if (picked.isEmpty()) "Select audio / video files" else "${picked.size} file(s) selected")
                }

                var langMenu by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { langMenu = true }) { Text("Language: " + (Catalog.languages.firstOrNull { it.second == lang }?.first ?: lang)) }
                    DropdownMenu(expanded = langMenu, onDismissRequest = { langMenu = false }) {
                        Catalog.languages.forEach { (n, c) -> DropdownMenuItem(text = { Text(n) }, onClick = { lang = c; langMenu = false }) }
                    }
                }

                Text("AI mode (all free, run on this phone)", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Preset.entries.forEach { pr ->
                        FilterChip(selected = asrId == pr.asrId && accurate == pr.accurate,
                            onClick = { asrId = pr.asrId; accurate = pr.accurate }, label = { Text(pr.label) })
                    }
                }
                Text(Preset.entries.firstOrNull { it.asrId == asrId && it.accurate == accurate }?.hint ?: "Custom combination",
                    style = MaterialTheme.typography.bodySmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Catalog.asr.forEach { m -> FilterChip(selected = asrId == m.id, onClick = { asrId = m.id }, label = { Text(m.title.removePrefix("Whisper ")) }) }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = accurate, onClick = { accurate = !accurate }, label = { Text("Accurate word alignment") })
                    FilterChip(selected = speakers, onClick = { speakers = !speakers }, label = { Text("Identify speakers") })
                }
                if (accurate && Catalog.alignerFor(lang) == null)
                    Text("No word-alignment model for this language: word timing will be approximate. Hindi and English get accurate alignment.",
                        color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)

                needed.forEach { m ->
                    Text("• ${m.title}: ${m.note}  ${if (m in missing) "(not downloaded)" else "✓"}", style = MaterialTheme.typography.bodySmall)
                }
                if (missing.isNotEmpty()) {
                    Button(enabled = !busy, onClick = {
                        dl = scope.launch {
                            busy = true
                            try {
                                missing.forEach { m -> status = "Downloading ${m.title}"; progress = 0f; store.download(m) { progress = it } }
                                rev++; status = "Models ready"
                            } catch (e: CancellationException) { status = "Download cancelled (it resumes next time)"; throw e
                            } catch (e: Exception) { status = "Download failed: ${e.message}" } finally { busy = false }
                        }
                    }) { Text("Download ${missing.size} model(s)") }
                } else {
                    Button(enabled = picked.isNotEmpty(), onClick = {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        picked.forEach { u -> db.enqueue(u.toString(), nameOf(u), lang, asrId, accurate, speakers) }
                        picked = emptyList()
                        startQueue()
                    }) { Text(if (picked.isEmpty()) "Transcribe in the background" else "Transcribe ${picked.size} file(s) in the background") }
                }
                if (status.isNotEmpty()) Text(status)
                if (busy) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                    TextButton(onClick = { dl?.cancel() }) { Text("Cancel download") }
                }

                if (jobs.isNotEmpty()) {
                    Text("Queue (keeps running when you leave the app)", style = MaterialTheme.typography.titleMedium)
                    if (queueActive) TextButton(onClick = { startQueue() }) { Text("Resume queue") }
                    jobs.forEach { j ->
                        JobRow(j,
                            onCancel = {
                                db.setStatus(j.spec.id, JobStatus.CANCELLED, "Cancelled", "")
                                if (j.status == JobStatus.RUNNING) TranscriptionService.cancel(j.spec.id)
                            },
                            onRemove = { File(filesDir, "jobs/${j.spec.id}.pcm").delete(); db.removeJob(j.spec.id) },
                            onRetry = { db.retry(j.spec.id); startQueue() },
                            onOpen = { j.projectId?.let { openProject(it) } })
                    }
                }

                if (projects.isNotEmpty()) {
                    Text("Recent projects", style = MaterialTheme.typography.titleMedium)
                    projects.forEach { p ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.title, maxLines = 1)
                                Text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(p.updatedMs)), style = MaterialTheme.typography.labelSmall)
                            }
                            TextButton(onClick = { openProject(p.id) }) { Text("Open") }
                            TextButton(onClick = { db.remove(p.id) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}
