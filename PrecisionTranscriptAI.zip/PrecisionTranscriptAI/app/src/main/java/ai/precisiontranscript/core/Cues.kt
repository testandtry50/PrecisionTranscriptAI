package ai.precisiontranscript.core

import kotlin.math.abs

data class Cue(val text: String, val startUs: Long, val endUs: Long, val speaker: Int)

/** Splits sentences into subtitle-sized cues using the word timestamps. Used for SRT and VTT only. */
object Cues {
    const val MAX_CHARS = 84                       // two lines of 42
    const val MAX_DURATION_US = 7_000_000L
    private const val LINE = 42

    fun build(sentences: List<Sentence>, maxChars: Int = MAX_CHARS, maxDurationUs: Long = MAX_DURATION_US): List<Cue> {
        val out = ArrayList<Cue>()
        for (s in sentences) {
            var cur = ArrayList<Word>()
            var len = 0
            fun flush() {
                if (cur.isEmpty()) return
                out.add(Cue(wrap(cur.joinToString(" ") { it.text }), cur.first().startUs, cur.last().endUs, s.speaker))
                cur = ArrayList(); len = 0
            }
            for (w in s.words) {
                if (cur.isNotEmpty() && (len + 1 + w.text.length > maxChars || w.endUs - cur.first().startUs > maxDurationUs)) flush()
                len += w.text.length + (if (cur.isEmpty()) 0 else 1)
                cur.add(w)
                if (len >= maxChars / 2 && w.text.lastOrNull() in setOf(',', ';', ':', '—')) flush()   // prefer natural breaks
            }
            flush()
        }
        return out
    }

    /** One line if it fits, else two lines split at the space nearest the middle. */
    private fun wrap(t: String): String {
        if (t.length <= LINE) return t
        val mid = t.length / 2
        var best = -1
        for (i in t.indices) if (t[i] == ' ' && (best < 0 || abs(i - mid) < abs(best - mid))) best = i
        return if (best < 0) t else t.substring(0, best) + "\n" + t.substring(best + 1)
    }
}
