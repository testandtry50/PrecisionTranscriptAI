package ai.precisiontranscript.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteOrder

const val RATE = 16_000

/** Decodes any audio/video file with Android's built-in codecs to 16 kHz mono PCM16 on disk (no FFmpeg needed). */
object AudioDecoder {
    fun decode(ctx: Context, uri: Uri, out: File, onProgress: (Float) -> Unit): Long {
        val ex = MediaExtractor().apply { setDataSource(ctx, uri, null) }
        var codec: MediaCodec? = null
        var count = 0L
        try {
            val track = (0 until ex.trackCount).firstOrNull {
                ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("No audio track found")
            ex.selectTrack(track)
            val fmt = ex.getTrackFormat(track)
            val total = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = c
            c.configure(fmt, null, null, 0); c.start()
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var step = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) / RATE.toDouble()
            var nextPos = 0.0; var idx = 0L; var prev = 0f
            val info = MediaCodec.BufferInfo()
            var inDone = false; var outDone = false
            BufferedOutputStream(FileOutputStream(out), 1 shl 16).use { os ->
                while (!outDone) {
                    if (!inDone) {
                        val i = c.dequeueInputBuffer(10_000)
                        if (i >= 0) {
                            val n = ex.readSampleData(c.getInputBuffer(i)!!, 0)
                            if (n < 0) {
                                c.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true
                            } else {
                                c.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                                if (total > 0) onProgress(ex.sampleTime.toFloat() / total)
                                ex.advance()
                            }
                        }
                    }
                    val o = c.dequeueOutputBuffer(info, 10_000)
                    if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val f = c.outputFormat
                        ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        step = f.getInteger(MediaFormat.KEY_SAMPLE_RATE) / RATE.toDouble()
                    } else if (o >= 0) {
                        val sb = c.getOutputBuffer(o)!!.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        repeat(info.size / (2 * ch)) {
                            var m = 0f
                            repeat(ch) { m += sb.get() }
                            m /= 32768f * ch
                            if (idx == 0L) prev = m
                            // linear-interpolation resampler, streaming
                            while (nextPos <= idx) {
                                val v = (prev + (m - prev) * (nextPos - (idx - 1)).toFloat()).coerceIn(-1f, 1f)
                                val s = (v * 32767f).toInt()
                                os.write(s and 0xFF); os.write((s shr 8) and 0xFF)
                                count++; nextPos += step
                            }
                            prev = m; idx++
                        }
                        c.releaseOutputBuffer(o, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    }
                }
            }
            return count
        } finally {
            codec?.let { runCatching { it.stop() }; it.release() }
            ex.release()
        }
    }
}

/** Random-access reader over the decoded PCM file, so hours of audio never sit in RAM. */
class PcmFile(file: File) : AutoCloseable {
    private val raf = RandomAccessFile(file, "r")
    val samples: Long = file.length() / 2

    fun read(start: Long, n: Int): ShortArray {
        val len = minOf(n.toLong(), samples - start).toInt()
        val b = ByteArray(len * 2)
        raf.seek(start * 2); raf.readFully(b)
        return ShortArray(len) { ((b[2 * it + 1].toInt() shl 8) or (b[2 * it].toInt() and 0xFF)).toShort() }
    }

    /** Whole file as floats in a single array (no intermediate ShortArray), read in 1M-sample blocks. */
    fun readFloats(start: Long = 0, n: Int = (samples - start).toInt()): FloatArray {
        val out = FloatArray(n)
        val buf = ByteArray(2 shl 20)
        raf.seek(start * 2)
        var i = 0
        while (i < out.size) {
            val n = minOf(1 shl 20, out.size - i)
            raf.readFully(buf, 0, n * 2)
            for (k in 0 until n) out[i + k] = ((buf[2 * k + 1].toInt() shl 8) or (buf[2 * k].toInt() and 0xFF)).toShort() / 32768f
            i += n
        }
        return out
    }

    override fun close() = raf.close()
}

/** [start,end) is what gets transcribed; [keepFrom,keepTo) is the part of it whose words are kept (all in samples). */
data class Window(val start: Long, val end: Long, val keepFrom: Long, val keepTo: Long)

object Chunker {
    const val MAX = 28 * RATE          // Whisper's 30 s window, with headroom
    const val OVERLAP = 4 * RATE       // consecutive windows share 4 s
    private const val MARGIN = RATE

    /** Overlapping windows; the hand-over point between two windows is chosen by [quietest] inside their shared audio. */
    fun plan(total: Long, quietest: (Long, Long) -> Long): List<Window> {
        val out = ArrayList<Window>()
        var start = 0L; var keepFrom = 0L
        while (true) {
            val end = minOf(start + MAX, total)
            if (end >= total) { out.add(Window(start, total, keepFrom, total)); return out }
            val next = end - OVERLAP
            val cut = quietest(next + MARGIN, end - MARGIN)
            out.add(Window(start, end, keepFrom, cut))
            keepFrom = cut; start = next
        }
    }

    /** Centre of the lowest-energy 50 ms frame in [from, to). */
    fun quietest(pcm: PcmFile, from: Long, to: Long): Long {
        val frame = RATE / 20
        val win = pcm.read(from, (to - from).toInt())
        if (win.size < frame) return (from + to) / 2
        var best = 0; var bestE = Double.MAX_VALUE; var i = 0
        while (i + frame <= win.size) {
            var e = 0.0
            for (j in i until i + frame) e += win[j].toDouble() * win[j]
            if (e < bestE) { bestE = e; best = i }
            i += frame / 2
        }
        return from + best + frame / 2
    }
}
