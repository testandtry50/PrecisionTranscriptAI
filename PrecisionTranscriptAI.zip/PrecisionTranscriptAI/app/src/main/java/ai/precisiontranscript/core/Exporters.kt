package ai.precisiontranscript.core

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

object Exporters {
    private fun tag(t: Transcript, spk: Int) = speakerLabel(t.speakerNames, spk) ?: ""
    private fun prefix(t: Transcript, spk: Int) = if (spk >= 0) "[${tag(t, spk)}] " else ""

    // Times are exported both as exact integer microseconds and as 6-decimal strings (keeps trailing zeros).
    private fun wordJson(t: Transcript, w: Word) = JSONObject().put("text", w.text)
        .put("start", w.startUs.sec6()).put("end", w.endUs.sec6())
        .put("start_us", w.startUs).put("end_us", w.endUs)
        .also { if (w.speaker >= 0) it.put("speaker", tag(t, w.speaker)) }

    private fun sentJson(t: Transcript, s: Sentence) = JSONObject().put("text", s.text)
        .put("start", s.startUs.sec6()).put("end", s.endUs.sec6())
        .put("start_us", s.startUs).put("end_us", s.endUs)
        .also { if (s.speaker >= 0) it.put("speaker", tag(t, s.speaker)) }

    fun wordsJson(t: Transcript): String =
        JSONObject().put("words", JSONArray(t.words.map { wordJson(t, it) })).toString(2)

    fun sentencesJson(t: Transcript): String =
        JSONObject().put("sentences", JSONArray(t.sentences.map { sentJson(t, it) })).toString(2)

    fun combinedJson(t: Transcript): String = JSONObject().put("sentences", JSONArray(t.sentences.map { s ->
        sentJson(t, s).put("words", JSONArray(s.words.map { wordJson(t, it) }))
    })).toString(2)

    // SRT/VTT only define millisecond precision, so these two are rounded to ms by format.
    private fun ts(us: Long, sep: Char): String {
        val ms = (us + 500) / 1000
        return String.format(Locale.ROOT, "%02d:%02d:%02d%c%03d", ms / 3_600_000, ms / 60_000 % 60, ms / 1000 % 60, sep, ms % 1000)
    }

    private fun cueText(t: Transcript, cues: List<Cue>, i: Int): String {
        val c = cues[i]
        val show = c.speaker >= 0 && (i == 0 || cues[i - 1].speaker != c.speaker)
        return (if (show) prefix(t, c.speaker) else "") + c.text
    }

    /** Subtitle files are built from cues: long sentences are split using word timestamps (<= 2 lines x 42 chars, <= 7 s). */
    fun srt(t: Transcript): String {
        val cues = Cues.build(t.sentences)
        return cues.indices.joinToString("\n") { i ->
            "${i + 1}\n${ts(cues[i].startUs, ',')} --> ${ts(cues[i].endUs, ',')}\n${cueText(t, cues, i)}\n"
        }
    }

    fun vtt(t: Transcript): String {
        val cues = Cues.build(t.sentences)
        return "WEBVTT\n\n" + cues.indices.joinToString("\n") { i ->
            "${ts(cues[i].startUs, '.')} --> ${ts(cues[i].endUs, '.')}\n${cueText(t, cues, i)}\n"
        }
    }

    fun txt(t: Transcript): String = t.sentences.joinToString("\n") { prefix(t, it.speaker) + it.text }

    fun csv(t: Transcript): String {
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val sb = StringBuilder("level,speaker,text,start,end,start_us,end_us\n")
        for (s in t.sentences) sb.append("sentence,${q(tag(t, s.speaker))},${q(s.text)},${s.startUs.sec6()},${s.endUs.sec6()},${s.startUs},${s.endUs}\n")
        for (w in t.words) sb.append("word,${q(tag(t, w.speaker))},${q(w.text)},${w.startUs.sec6()},${w.endUs.sec6()},${w.startUs},${w.endUs}\n")
        return sb.toString()
    }
}

enum class ExportFormat(val label: String, val ext: String, val render: (Transcript) -> String) {
    WORDS("Word JSON", "words.json", { Exporters.wordsJson(it) }),
    SENTENCES("Sentence JSON", "sentences.json", { Exporters.sentencesJson(it) }),
    COMBINED("Combined JSON", "combined.json", { Exporters.combinedJson(it) }),
    SRT("SRT", "srt", { Exporters.srt(it) }),
    VTT("VTT", "vtt", { Exporters.vtt(it) }),
    CSV("CSV", "csv", { Exporters.csv(it) }),
    TXT("TXT", "txt", { Exporters.txt(it) }),
}
