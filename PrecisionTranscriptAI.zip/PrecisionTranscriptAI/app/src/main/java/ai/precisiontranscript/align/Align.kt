package ai.precisiontranscript.align

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.precisiontranscript.audio.RATE
import ai.precisiontranscript.core.Word
import org.json.JSONObject
import java.io.File
import java.nio.FloatBuffer
import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt

/** [approximate] = true when the timing was NOT obtained by forced alignment. */
data class Alignment(val words: List<Word>, val approximate: Boolean)

/** Words get times in microseconds relative to the start of [pcm]. */
interface WordAligner : AutoCloseable {
    fun align(pcm: ShortArray, text: String): Alignment
    override fun close() {}
}

private fun splitWords(text: String) = text.split(Regex("\\s+")).filter { it.isNotEmpty() }

/** FAST mode: spreads words over the non-silent span by character count. Approximate. */
class ProportionalAligner : WordAligner {
    override fun align(pcm: ShortArray, text: String) = Alignment(spread(pcm, text), true)

    fun spread(pcm: ShortArray, text: String): List<Word> {
        val words = splitWords(text)
        if (words.isEmpty()) return emptyList()
        val first = pcm.indexOfFirst { abs(it.toInt()) > 600 }.coerceAtLeast(0)
        val last = pcm.indexOfLast { abs(it.toInt()) > 600 }.let { if (it < 0) pcm.size - 1 else it }
        val t0 = first * 1_000_000L / RATE
        val t1 = (last + 1) * 1_000_000L / RATE
        val total = words.sumOf { it.length }
        var acc = 0
        return words.map { w ->
            val s = t0 + (t1 - t0) * acc / total
            acc += w.length
            Word(w, s, t0 + (t1 - t0) * acc / total)
        }
    }
}

/**
 * ACCURATE mode: CTC forced alignment. Runs a wav2vec2-style CTC model (ONNX) to get per-frame
 * log-probabilities, then Viterbi-aligns the recognised characters to those frames.
 */
class CtcAligner(modelFile: File, vocabFile: File, private val blank: Int = 0) : WordAligner {
    private val vocab: Map<String, Int> = JSONObject(vocabFile.readText()).let { j -> j.keys().asSequence().associateWith { j.getInt(it) } }
    private val env = OrtEnvironment.getEnvironment()
    private val session = env.createSession(modelFile.path, OrtSession.SessionOptions())

    override fun align(pcm: ShortArray, text: String): Alignment {
        val words = splitWords(text)
        if (words.isEmpty()) return Alignment(emptyList(), false)
        val ids = ArrayList<Int>(); val owner = ArrayList<Int>()
        words.forEachIndexed { wi, w ->
            for (c in Normalizer.normalize(w, Normalizer.Form.NFC)) {
                val s = c.toString()
                val id = vocab[s] ?: vocab[s.uppercase()] ?: vocab[s.lowercase()]
                if (id != null) { ids.add(id); owner.add(wi) }
            }
        }
        if (ids.isEmpty()) return ProportionalAligner().align(pcm, text)
        val em = emissions(pcm)
        check(em.isNotEmpty() && em[0].size > vocab.values.max()) { "vocab.json does not match the aligner model's output size" }
        val spans = ctcViterbi(em, ids.toIntArray(), blank) ?: return ProportionalAligner().align(pcm, text)

        val durUs = pcm.size * 1_000_000L / RATE
        val frames = em.size
        val start = LongArray(words.size) { -1 }
        val end = LongArray(words.size) { -1 }
        for (k in ids.indices) {
            val w = owner[k]
            if (start[w] < 0) start[w] = spans[k].first * durUs / frames
            end[w] = (spans[k].last + 1) * durUs / frames
        }
        // Words with no alignable characters (digits, punctuation, other scripts) share the gap between neighbours.
        var i = 0
        while (i < words.size) {
            if (start[i] >= 0) { i++; continue }
            var j = i
            while (j < words.size && start[j] < 0) j++
            val l = if (i > 0) end[i - 1] else if (j < words.size) start[j] else 0L
            val r = if (j < words.size) start[j] else l
            for (k in i until j) {
                start[k] = l + (r - l) * (k - i) / (j - i)
                end[k] = l + (r - l) * (k - i + 1) / (j - i)
            }
            i = j
        }
        return Alignment(words.indices.map { Word(words[it], start[it], end[it]) }, false)
    }

    private fun emissions(pcm: ShortArray): Array<FloatArray> {
        val x = FloatArray(pcm.size) { pcm[it] / 32768f }
        val mean = x.average().toFloat()
        val sd = sqrt(x.fold(0.0) { a, v -> a + (v - mean) * (v - mean) } / x.size + 1e-7).toFloat()
        for (i in x.indices) x[i] = (x[i] - mean) / sd
        OnnxTensor.createTensor(env, FloatBuffer.wrap(x), longArrayOf(1, x.size.toLong())).use { input ->
            session.run(mapOf(session.inputNames.first() to input)).use { out ->
                @Suppress("UNCHECKED_CAST")
                val logits = (out[0] as OnnxTensor).value as Array<Array<FloatArray>>
                return Array(logits[0].size) { t -> logSoftmax(logits[0][t]) }
            }
        }
    }

    private fun logSoftmax(v: FloatArray): FloatArray {
        val m = v.max()
        var s = 0.0
        for (x in v) s += exp((x - m).toDouble())
        val l = (m + ln(s)).toFloat()
        return FloatArray(v.size) { v[it] - l }
    }

    override fun close() = session.close()
}

/** Standard CTC Viterbi. Returns, for each target token, the inclusive frame range it occupies; null if infeasible. */
internal fun ctcViterbi(em: Array<FloatArray>, tok: IntArray, blank: Int): List<IntRange>? {
    val frames = em.size
    val n = tok.size
    val states = 2 * n + 1                       // blank, tok0, blank, tok1, ..., blank
    if (frames < n) return null
    val neg = -1e30f
    fun label(s: Int) = if (s % 2 == 0) blank else tok[s / 2]
    var prev = FloatArray(states) { neg }
    prev[0] = em[0][blank]; prev[1] = em[0][tok[0]]
    val back = Array(frames) { ByteArray(states) }
    for (t in 1 until frames) {
        val cur = FloatArray(states)
        for (s in 0 until states) {
            var best = prev[s]; var step = 0
            if (s >= 1 && prev[s - 1] > best) { best = prev[s - 1]; step = 1 }
            if (s >= 3 && s % 2 == 1 && tok[s / 2] != tok[s / 2 - 1] && prev[s - 2] > best) { best = prev[s - 2]; step = 2 }
            cur[s] = best + em[t][label(s)]
            back[t][s] = step.toByte()
        }
        prev = cur
    }
    var s = if (prev[states - 2] > prev[states - 1]) states - 2 else states - 1
    if (prev[s] < -1e20f) return null
    val first = IntArray(n); val last = IntArray(n) { -1 }
    for (t in frames - 1 downTo 0) {
        if (s % 2 == 1) { val k = s / 2; if (last[k] < 0) last[k] = t; first[k] = t }
        s -= back[t][s].toInt()
    }
    return List(n) { first[it]..last[it] }
}
