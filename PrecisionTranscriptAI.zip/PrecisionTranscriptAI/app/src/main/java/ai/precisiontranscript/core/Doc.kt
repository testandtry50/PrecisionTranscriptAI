package ai.precisiontranscript.core

/** Everything an edit can change. cuts/joins hold word ids, so they survive inserts and deletes. */
data class State(
    val words: List<Word>, val cuts: Set<Int> = emptySet(), val joins: Set<Int> = emptySet(),
    val names: Map<Int, String> = emptyMap(),
)

/** The untouched transcription, looked up by stable word id (an inserted word has no original). */
class Original(val words: List<Word>) {
    private val byId = words.associateBy { it.id }
    operator fun get(id: Int): Word? = byId[id]
}

/**
 * The editable document. The word list is the single source of truth: sentences (text, start, end, speaker)
 * are always derived from it by [SentenceGrouper]; manual splits/merges are only break overrides by word id.
 */
data class Doc(
    val original: Original,
    val state: State,
    val past: List<State> = emptyList(),
    val future: List<State> = emptyList(),
) {
    val words: List<Word> get() = state.words
    val canUndo get() = past.isNotEmpty()
    val canRedo get() = future.isNotEmpty()
    val modified get() = state.copy(names = emptyMap()) != State(original.words)

    fun sentences(): List<Sentence> = SentenceGrouper.group(state.words, state.cuts, state.joins)
    fun toTranscript(warnings: List<String> = emptyList()) = Transcript(words, sentences(), warnings, state.names)
    fun label(speaker: Int): String = speakerLabel(state.names, speaker) ?: "S?"

    /** Replaces all custom speaker names. Entries that are blank or equal to the default ("S2") are not stored. */
    fun withNames(m: Map<Int, String>): Doc =
        commit(state.copy(names = m.mapValues { it.value.trim() }.filter { (k, v) -> v.isNotEmpty() && v != "S${k + 1}" }))

    fun commit(next: State): Doc =
        if (next == state) this
        else copy(state = next, past = (past + listOf(state)).takeLast(MAX_UNDO), future = emptyList())

    private fun commitWords(next: List<Word>) = commit(state.copy(words = next))

    fun update(i: Int, text: String, startUs: Long, endUs: Long): Doc =
        commitWords(words.toMutableList().also { it[i] = it[i].copy(text = text, startUs = startUs, endUs = endUs) })

    /** Inserts a new word at position [index] (0..size); it inherits the previous word's speaker. */
    fun insertAt(index: Int, text: String, startUs: Long, endUs: Long): Doc {
        if (index < 0 || index > words.size) return this
        val spk = words.getOrNull(index - 1)?.speaker ?: words.firstOrNull()?.speaker ?: -1
        val id = maxOf(words.maxOfOrNull { it.id } ?: -1, original.words.maxOfOrNull { it.id } ?: -1) + 1
        return commitWords(words.toMutableList().also { it.add(index, Word(text, startUs, endUs, spk, id)) })
    }

    /** Deletes word [i] (the last remaining word cannot be deleted). A sentence break on it moves to the previous word. */
    fun delete(i: Int): Doc {
        if (words.size <= 1 || i !in words.indices) return this
        val gone = words[i].id
        val prev = words.getOrNull(i - 1)?.id
        fun move(s: Set<Int>) = if (gone !in s) s else (s - gone).let { if (prev != null) it + prev else it }
        return commit(State(words.toMutableList().also { it.removeAt(i) }, move(state.cuts), move(state.joins), state.names))
    }

    fun undo(): Doc = if (past.isEmpty()) this else copy(state = past.last(), past = past.dropLast(1), future = future + listOf(state))
    fun redo(): Doc = if (future.isEmpty()) this else copy(state = future.last(), future = future.dropLast(1), past = past + listOf(state))

    /** Back to the original transcription: undoes text/timing edits, inserts, deletes, splits, merges. Keeps speaker names. */
    fun revertAll(): Doc = commit(State(original.words, names = state.names))

    /** Word at position [i] becomes the first word of a new sentence. No-op if it already is one. */
    fun splitBefore(i: Int): Doc {
        if (i <= 0 || i >= words.size || sentences().any { it.firstIndex == i }) return this
        val b = words[i - 1].id
        return commit(state.copy(cuts = state.cuts + b, joins = state.joins - b))
    }

    /** Merges the sentence ending at word position [i] with the next one; the next sentence adopts this one's speaker. */
    fun mergeAfter(i: Int): Doc {
        if (i < 0 || i >= words.lastIndex) return this
        val nx = sentences().firstOrNull { it.firstIndex == i + 1 } ?: return this
        val spk = words[i].speaker
        val range = nx.firstIndex until nx.firstIndex + nx.words.size
        val w = if (nx.speaker == spk) words else words.mapIndexed { k, x -> if (k in range) x.copy(speaker = spk) else x }
        val b = words[i].id
        return commit(state.copy(words = w, cuts = state.cuts - b, joins = state.joins + b))
    }

    fun setSpeaker(from: Int, to: Int, speaker: Int): Doc =
        commitWords(words.mapIndexed { k, w -> if (k in from..to) w.copy(speaker = speaker) else w })

    /** Positions of words whose text contains [query]. Matching is inside single words (each word is timed separately). */
    fun find(query: String, ignoreCase: Boolean = true): List<Int> =
        if (query.isEmpty()) emptyList() else words.indices.filter { words[it].text.contains(query, ignoreCase) }

    /** Replaces [find] inside every matching word in one undoable step. Words that would become empty are left alone. */
    fun replaceAll(find: String, with: String, ignoreCase: Boolean = true): Doc {
        if (find.isEmpty() || with.any { it.isWhitespace() }) return this
        return commitWords(words.map {
            val t = it.text.replace(find, with, ignoreCase)
            if (t.isBlank() || t == it.text) it else it.copy(text = t)
        })
    }

    /** Every word of speaker [from] becomes speaker [into]; [from]'s custom name is dropped. */
    fun mergeSpeaker(from: Int, into: Int): Doc {
        if (from == into || from < 0 || into < 0) return this
        return commit(state.copy(words = words.map { if (it.speaker == from) it.copy(speaker = into) else it }, names = state.names - from))
    }

    /** Next speaker when cycling: 0..max, then one new speaker, then back to 0. */
    fun nextSpeaker(cur: Int): Int {
        val max = words.maxOfOrNull { it.speaker } ?: -1
        return if (cur + 1 > max + 1) 0 else cur + 1
    }

    companion object {
        const val MAX_UNDO = 200
        /** Gives every word a unique id (0..n-1) unless they already have unique ones. */
        fun of(words: List<Word>): Doc {
            val w = if (words.map { it.id }.toSet().size == words.size) words else words.mapIndexed { i, x -> x.copy(id = i) }
            return Doc(Original(w), State(w))
        }
    }
}

object Validate {
    /** Error message, or null when the edit is allowed. [maxUs] <= 0 means the audio length is unknown. */
    fun word(words: List<Word>, i: Int, text: String, startUs: Long, endUs: Long, maxUs: Long): String? = when {
        text.isBlank() -> "Text can't be empty"
        text.any { it.isWhitespace() } -> "A word can't contain spaces"
        startUs < 0 -> "Start can't be negative"
        endUs < startUs -> "End can't be before start"
        i > 0 && startUs < words[i - 1].endUs -> "Start overlaps the previous word (it ends at ${words[i - 1].endUs.sec6()})"
        i < words.lastIndex && endUs > words[i + 1].startUs -> "End overlaps the next word (it starts at ${words[i + 1].startUs.sec6()})"
        maxUs > 0 && endUs > maxUs -> "End is past the end of the audio (${maxUs.sec6()})"
        else -> null
    }
}

private val SEC = Regex("""(-?)(\d+)(?:\.(\d{1,6}))?""")

/** "1.234567" -> 1234567 µs, with integer maths only. At most 6 decimals; "," is accepted as the decimal mark. */
fun parseSec6(input: String): Long? {
    val m = SEC.matchEntire(input.trim().replace(',', '.')) ?: return null
    val sec = m.groupValues[2].toLongOrNull() ?: return null
    if (sec > 31_536_000L) return null
    val us = sec * 1_000_000L + m.groupValues[3].padEnd(6, '0').toLong()
    return if (m.groupValues[1] == "-") -us else us
}
