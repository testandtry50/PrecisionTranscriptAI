package ai.precisiontranscript.asr

// Kotlin API files copied from the sherpa-onnx repo (sherpa-onnx/kotlin-api/*.kt), see README.
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineWhisperModelConfig
import java.io.File

interface SpeechRecognizer : AutoCloseable {
    fun transcribe(pcm: ShortArray): String
}

/** Offline Whisper via sherpa-onnx. [modelDir] holds *encoder*.onnx, *decoder*.onnx and *tokens*.txt. language: "hi", "en", or "" = auto. */
class SherpaWhisper(modelDir: File, language: String) : SpeechRecognizer {
    private val rec: OfflineRecognizer

    init {
        fun find(vararg parts: String) = modelDir.listFiles()!!.first { f -> parts.all { f.name.contains(it) } && !f.name.endsWith(".part") }.path
        rec = OfflineRecognizer(
            assetManager = null,
            config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
                modelConfig = OfflineModelConfig(
                    whisper = OfflineWhisperModelConfig(
                        encoder = find("encoder", ".onnx"), decoder = find("decoder", ".onnx"),
                        language = language, task = "transcribe",
                    ),
                    tokens = find("tokens"), numThreads = 4, modelType = "whisper",
                ),
            ),
        )
    }

    override fun transcribe(pcm: ShortArray): String {
        val s = rec.createStream()
        s.acceptWaveform(FloatArray(pcm.size) { pcm[it] / 32768f }, 16000)
        rec.decode(s)
        val text = rec.getResult(s).text
        s.release()
        return text.trim()
    }

    override fun close() = rec.release()
}
