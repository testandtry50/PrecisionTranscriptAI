package ai.precisiontranscript.ui

import ai.precisiontranscript.core.Doc
import ai.precisiontranscript.core.ExportFormat
import ai.precisiontranscript.core.Sentence
import ai.precisiontranscript.core.SentenceGrouper
import ai.precisiontranscript.core.Sync
import ai.precisiontranscript.core.Validate
import ai.precisiontranscript.core.Word
import ai.precisiontranscript.core.clock
import ai.precisiontranscript.core.parseSec6
import ai.precisiontranscript.core.sec6
import ai.precisiontranscript.player.PlayerController
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun EditorScreen(
    doc: Doc, warnings: List<String>, saveNote: String, p: PlayerController,
    onDoc: (Doc) -> Unit, onNew: () -> Unit, onExport: (ExportFormat) -> Unit,
) {
    var follow by remember { mutableStateOf(true) }
    var editing by remember { mutableStateOf<Int?>(null) }
    var naming by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    var finding by remember { mutableStateOf(false) }
    val sentences = remember(doc.state) { doc.sentences() }   // derived from the words, never stored
    val modified = remember(doc.state) { doc.modified }
    val cursor by remember(sentences) {
        derivedStateOf {
            val s = Sync.sentenceAt(sentences, p.positionUs)
            s to (if (s < 0) -1 else Sync.wordAt(sentences[s].words, p.positionUs))
        }
    }
    val (curSent, curWord) = cursor
    val edit = { i: Int -> p.pause(); adding = false; editing = i }

    editing?.let { i ->
        if (adding || i < doc.words.size)
            WordEditDialog(doc, i, adding, p,
                onDismiss = { editing = null; adding = false },
                onSave = { onDoc(it); editing = null; adding = false },
                onAdd = { at -> editing = at; adding = true })
    }

    if (naming) SpeakersDialog(doc, onDismiss = { naming = false }, onSave = { onDoc(it); naming = false })
    if (finding) FindDialog(doc, onDismiss = { finding = false }, onApply = onDoc,
        onJump = { gi -> follow = true; p.pause(); p.seekToUs(doc.words[gi].startUs, play = false) })   // the list follows the playhead

    Scaffold(bottomBar = { PlayerBar(sentences, p, curSent, curWord, edit) }) { pad ->
        Column(Modifier.padding(pad)) {
            Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onNew) { Text("New") }
                TextButton(onClick = { onDoc(doc.undo()) }, enabled = doc.canUndo) { Text("Undo") }
                TextButton(onClick = { onDoc(doc.redo()) }, enabled = doc.canRedo) { Text("Redo") }
                TextButton(onClick = { onDoc(doc.revertAll()) }, enabled = modified) { Text("Revert") }
            }
            Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = follow, onClick = { follow = !follow }, label = { Text("Follow") })
                TextButton(onClick = { naming = true }, enabled = doc.words.any { it.speaker >= 0 }) { Text("Speakers") }
                TextButton(onClick = { finding = true }) { Text("Find") }
                LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ExportFormat.entries) { f -> AssistChip(onClick = { onExport(f) }, label = { Text(f.label) }) }
                }
            }
            Text("Tap a word to play · long-press to edit   $saveNote", Modifier.padding(horizontal = 12.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall)
            if (warnings.isNotEmpty())
                Text(warnings.joinToString(), Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
            TranscriptList(doc, sentences, p, curSent, curWord, follow, edit, onDoc, Modifier.weight(1f))
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun TranscriptList(
    doc: Doc, sentences: List<Sentence>, p: PlayerController, curSent: Int, curWord: Int,
    follow: Boolean, onEdit: (Int) -> Unit, onDoc: (Doc) -> Unit, modifier: Modifier = Modifier,
) {
    val state = rememberLazyListState()
    LaunchedEffect(curSent, follow) {
        if (!follow || curSent < 0) return@LaunchedEffect
        val info = state.layoutInfo
        val item = info.visibleItemsInfo.firstOrNull { it.index == curSent }
        val fullyVisible = item != null && item.offset >= 0 && item.offset + item.size <= info.viewportEndOffset
        if (!fullyVisible) state.animateScrollToItem(curSent)
    }
    LazyColumn(modifier, state = state) {
        itemsIndexed(sentences) { i, s ->
            val active = i == curSent
            Column(
                Modifier.fillMaxWidth()
                    .background(if (active) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                    .combinedClickable(onClick = { p.playRange(s.startUs, s.endUs) })      // tap row: replay sentence
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${i + 1}   ${s.startUs.sec6()} → ${s.endUs.sec6()}", Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace)
                    val last = s.firstIndex + s.words.size - 1
                    TextButton(onClick = { onDoc(doc.setSpeaker(s.firstIndex, last, doc.nextSpeaker(s.speaker))) }, contentPadding = PaddingValues(horizontal = 6.dp)) {
                        Text(doc.label(s.speaker), maxLines = 1)
                    }
                    if (i < sentences.lastIndex)
                        TextButton(onClick = { onDoc(doc.mergeAfter(last)) }, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("Merge ↓") }
                }
                FlowRow {
                    s.words.forEachIndexed { j, w ->
                        val gi = s.firstIndex + j
                        val on = active && j == curWord
                        val changed = doc.original[w.id] != w      // edited, or inserted (no original)
                        Text(
                            w.text,
                            Modifier.padding(end = 2.dp)
                                .background(if (on) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(4.dp))
                                .combinedClickable(onClick = { p.seekToUs(maxOf(0L, w.startUs - p.preRollUs)) }, onLongClick = { onEdit(gi) })
                                .padding(horizontal = 3.dp, vertical = 2.dp),
                            color = when { on -> MaterialTheme.colorScheme.onPrimary; changed -> MaterialTheme.colorScheme.tertiary; else -> Color.Unspecified },
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WordEditDialog(
    doc: Doc, index: Int, adding: Boolean, p: PlayerController,
    onDismiss: () -> Unit, onSave: (Doc) -> Unit, onAdd: (Int) -> Unit,
) {
    // When adding, [index] is the insertion position and the new word defaults to the gap before the next word.
    val prev = doc.words.getOrNull(index - 1)
    val next = doc.words.getOrNull(if (adding) index else index + 1)
    val cur = if (adding) {
        val s0 = prev?.endUs ?: 0L
        Word("", s0, minOf(s0 + 300_000L, next?.startUs ?: Long.MAX_VALUE))
    } else doc.words[index]
    val orig = if (adding) null else doc.original[cur.id]
    var text by remember(index, adding) { mutableStateOf(cur.text) }
    var start by remember(index, adding) { mutableStateOf(cur.startUs.sec6()) }
    var end by remember(index, adding) { mutableStateOf(cur.endUs.sec6()) }
    val s = parseSec6(start)
    val e = parseSec6(end)
    val simulated = remember(doc.state, index, adding) {
        if (adding) doc.words.toMutableList().also { it.add(index, Word("x", 0, 0)) } else doc.words
    }
    val problem = when {
        s == null -> "Start: enter seconds, e.g. 1.234567"
        e == null -> "End: enter seconds, e.g. 2.450000"
        else -> Validate.word(simulated, index, text.trim(), s, e, p.durationUs)
    }
    val canSplit = remember(doc.state, index, adding) { !adding && index > 0 && doc.sentences().none { it.firstIndex == index } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (adding) "Add word" else "Edit word ${index + 1}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("Text") }, singleLine = true)
                TimeField("Start (s)", start) { start = it }
                TimeField("End (s)", end) { end = it }
                if (problem != null) Text(problem, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { if (s != null && e != null && e >= s) p.playRange(s, e) }) { Text("Play word") }
                    TextButton(onClick = { if (s != null && e != null && e >= s) p.playRange(maxOf(0L, s - 1_000_000), e + 1_000_000) }) { Text("Play ±1 s") }
                }
                if (!adding) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { onAdd(index) }) { Text("Add before") }
                        TextButton(onClick = { onAdd(index + 1) }) { Text("Add after") }
                    }
                    if (canSplit) TextButton(onClick = {
                        // apply any valid pending edit first, then start a new sentence at this word
                        val d1 = if (s != null && e != null && problem == null) doc.update(index, text.trim(), s, e) else doc
                        onSave(d1.splitBefore(index))
                    }) { Text("Split sentence before this word") }
                    if (orig != null && (text.trim() != orig.text || s != orig.startUs || e != orig.endUs)) {
                        TextButton(onClick = { text = orig.text; start = orig.startUs.sec6(); end = orig.endUs.sec6() }) { Text("Reset to original") }
                    }
                    TextButton(enabled = doc.words.size > 1, onClick = { onSave(doc.delete(index)) }) {
                        Text("Delete word", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = problem == null, onClick = {
                if (s != null && e != null && problem == null)
                    onSave(if (adding) doc.insertAt(index, text.trim(), s, e) else doc.update(index, text.trim(), s, e))
            }) { Text(if (adding) "Add" else "Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun TimeField(label: String, value: String, onChange: (String) -> Unit) {
    val nudge = { d: Long -> parseSec6(value)?.let { onChange((it + d).coerceAtLeast(0L).sec6()) }; Unit }
    val tight = PaddingValues(horizontal = 6.dp)
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value, onChange, Modifier.weight(1f), label = { Text(label) }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            textStyle = TextStyle(fontFamily = FontFamily.Monospace),
        )
        TextButton(onClick = { nudge(-10_000) }, contentPadding = tight) { Text("−10ms") }
        TextButton(onClick = { nudge(10_000) }, contentPadding = tight) { Text("+10ms") }
    }
}

@Composable
fun PlayerBar(sentences: List<Sentence>, p: PlayerController, curSent: Int, curWord: Int, onEdit: (Int) -> Unit) {
    Surface(tonalElevation = 3.dp) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val sent = sentences.getOrNull(curSent)
            val w = sent?.words?.getOrNull(curWord)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (w != null) "${w.text}   ${w.startUs.sec6()} → ${w.endUs.sec6()}" else "—",
                    Modifier.weight(1f), style = MaterialTheme.typography.labelMedium, fontFamily = FontFamily.Monospace, maxLines = 1,
                )
                if (sent != null && w != null) TextButton(onClick = { onEdit(sent.firstIndex + curWord) }) { Text("Edit") }
            }
            var drag by remember { mutableStateOf<Float?>(null) }
            Slider(
                value = drag ?: (p.positionUs / 1000f),
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { p.seekToUs(it.toLong() * 1000, play = p.isPlaying) }; drag = null },
                valueRange = 0f..maxOf(1L, p.durationUs / 1000).toFloat(),
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(p.positionUs.clock(), fontFamily = FontFamily.Monospace)
                Text(p.durationUs.clock(), fontFamily = FontFamily.Monospace)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { p.skipMs(-5000) }, Modifier.weight(1f)) { Text("−5s") }
                OutlinedButton(onClick = { p.toggle() }, Modifier.weight(1.4f)) { Text(if (p.isPlaying) "Pause" else "Play") }
                OutlinedButton(onClick = { p.stop() }, Modifier.weight(1f)) { Text("Stop") }
                OutlinedButton(onClick = { p.skipMs(5000) }, Modifier.weight(1f)) { Text("+5s") }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)) { sp ->
                    FilterChip(selected = p.speed == sp, onClick = { p.setSpeed(sp) }, label = { Text(sp.toString().removeSuffix(".0") + "x") })
                }
            }
        }
    }
}

@Composable
fun SpeakersDialog(doc: Doc, onDismiss: () -> Unit, onSave: (Doc) -> Unit) {
    val ids = remember(doc.state) { doc.words.map { it.speaker }.filter { it >= 0 }.distinct().sorted() }
    val names = remember(doc.state) { mutableStateMapOf<Int, String>().apply { ids.forEach { put(it, doc.label(it)) } } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Speakers") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ids.forEach { id ->
                    key(id) {
                        var menu by remember { mutableStateOf(false) }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(names[id] ?: "", { names[id] = it }, Modifier.weight(1f), label = { Text("Speaker ${id + 1}") }, singleLine = true)
                            if (ids.size > 1) Box {
                                TextButton(onClick = { menu = true }) { Text("Merge into…") }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    ids.filter { it != id }.forEach { target ->
                                        DropdownMenuItem(text = { Text(doc.label(target)) }, onClick = {
                                            menu = false
                                            onSave(doc.withNames(names.toMap()).mergeSpeaker(id, target))
                                        })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(doc.withNames(names.toMap())) }) { Text("Save names") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun FindDialog(doc: Doc, onDismiss: () -> Unit, onApply: (Doc) -> Unit, onJump: (Int) -> Unit) {
    var q by remember { mutableStateOf("") }
    var r by remember { mutableStateOf("") }
    var pos by remember { mutableIntStateOf(-1) }
    val hits = remember(doc.state, q) { doc.find(q) }
    val badReplacement = r.any { it.isWhitespace() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Find & replace") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(q, { q = it; pos = -1 }, Modifier.fillMaxWidth(), label = { Text("Find (inside a word)") }, singleLine = true)
                OutlinedTextField(r, { r = it }, Modifier.fillMaxWidth(), label = { Text("Replace with") }, singleLine = true)
                Text(if (q.isEmpty()) "Type to search" else "${hits.size} matching word(s)", style = MaterialTheme.typography.bodySmall)
                if (badReplacement) Text("A replacement can't contain spaces: every word has its own timing.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(enabled = hits.isNotEmpty(), onClick = { pos = (pos + 1) % hits.size; onJump(hits[pos]) }) { Text("Next") }
                    TextButton(enabled = hits.isNotEmpty() && !badReplacement, onClick = { onApply(doc.replaceAll(q, r)) }) { Text("Replace all") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}
