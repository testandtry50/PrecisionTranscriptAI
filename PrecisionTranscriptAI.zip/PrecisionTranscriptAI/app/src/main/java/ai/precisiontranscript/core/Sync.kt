package ai.precisiontranscript.core

import java.util.Locale

/** Maps a playback position to the word / sentence being spoken. Lists must be sorted by start (Reconcile.monotonic guarantees it). */
object Sync {
    const val WORD_HOLD_US = 200_000L          // a word stays highlighted briefly after it ends
    const val SENTENCE_HOLD_US = 1_000_000L

    private inline fun lastStartedAt(n: Int, start: (Int) -> Long, pos: Long): Int {
        var lo = 0; var hi = n - 1; var r = -1
        while (lo <= hi) {
            val m = (lo + hi) ushr 1
            if (start(m) <= pos) { r = m; lo = m + 1 } else hi = m - 1
        }
        return r
    }

    fun wordAt(words: List<Word>, posUs: Long, holdUs: Long = WORD_HOLD_US): Int {
        val i = lastStartedAt(words.size, { words[it].startUs }, posUs)
        return if (i >= 0 && posUs <= words[i].endUs + holdUs) i else -1
    }

    fun sentenceAt(sentences: List<Sentence>, posUs: Long, holdUs: Long = SENTENCE_HOLD_US): Int {
        val i = lastStartedAt(sentences.size, { sentences[it].startUs }, posUs)
        return if (i >= 0 && posUs <= sentences[i].endUs + holdUs) i else -1
    }
}

/** Media3 seeks in whole milliseconds; round up so playback never starts before the word does. */
fun Long.usToMsCeil(): Long = (this + 999) / 1000

/** Player clock: mm:ss.mmm (or h:mm:ss.mmm). Millisecond precision, because that is all the player really has. */
fun Long.clock(): String {
    val ms = this / 1000
    val h = ms / 3_600_000; val m = ms / 60_000 % 60; val s = ms / 1000 % 60
    return if (h > 0) String.format(Locale.ROOT, "%d:%02d:%02d.%03d", h, m, s, ms % 1000)
    else String.format(Locale.ROOT, "%02d:%02d.%03d", m, s, ms % 1000)
}
