package ai.precisiontranscript

import ai.precisiontranscript.align.ctcViterbi
import ai.precisiontranscript.audio.Chunker
import ai.precisiontranscript.audio.RATE
import ai.precisiontranscript.core.Exporters
import ai.precisiontranscript.core.Cues
import ai.precisiontranscript.core.Doc
import ai.precisiontranscript.core.Eta
import ai.precisiontranscript.core.WordDiff
import ai.precisiontranscript.core.SpeakerSegment
import ai.precisiontranscript.core.SpeakerStitch
import ai.precisiontranscript.core.Speakers
import ai.precisiontranscript.models.Catalog
import ai.precisiontranscript.core.Reconcile
import ai.precisiontranscript.core.Validate
import ai.precisiontranscript.core.parseSec6
import ai.precisiontranscript.core.Sentence
import ai.precisiontranscript.core.Sync
import ai.precisiontranscript.core.clock
import ai.precisiontranscript.core.usToMsCeil
import ai.precisiontranscript.core.SentenceGrouper
import ai.precisiontranscript.core.Transcript
import ai.precisiontranscript.core.Word
import ai.precisiontranscript.core.sec6
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.ln

class EngineTest {
    private var nextTestId = 0
    private fun w(t: String, s: Long, e: Long) = Word(t, s, e, -1, nextTestId++)   // unique ids, like a real document

    @Test fun sec6IsExact() {
        assertEquals("1.234567", 1_234_567L.sec6())
        assertEquals("0.000001", 1L.sec6())
        assertEquals("3600.500000", 3_600_500_000L.sec6())
    }

    @Test fun groupsSentences() {
        val ws = listOf(w("I", 0, 1), w("want", 1, 2), w("home.", 2, 3), w("कहाँ", 4, 5), w("हो?", 5, 6), w("Dr.", 7, 8), w("Rao", 8, 9))
        val s = SentenceGrouper.group(ws)
        assertEquals(listOf("I want home.", "कहाँ हो?", "Dr. Rao"), s.map { it.text })
        assertEquals(7, s.sumOf { it.words.size })
        assertEquals(2, SentenceGrouper.group(listOf(w("a", 0, 1_000_000), w("b", 4_000_000, 5_000_000))).size)
    }

    @Test fun srtRoundsToMilliseconds() {
        val t = Transcript(emptyList(), SentenceGrouper.group(listOf(w("Hello.", 1_234_567, 2_450_000))))
        assertTrue(Exporters.srt(t).contains("00:00:01,235 --> 00:00:02,450"))
    }

    @Test fun ctcFindsTokenFrames() {
        // vocab 0=blank 1=a 2=b 3=c ; target a b b c ; frames: _ a a _ b _ b b c _
        val lab = intArrayOf(0, 1, 1, 0, 2, 0, 2, 2, 3, 0)
        val em = Array(lab.size) { t -> FloatArray(4) { k -> if (k == lab[t]) ln(0.9f) else ln(0.033f) } }
        val spans = ctcViterbi(em, intArrayOf(1, 2, 2, 3), 0)
        assertNotNull(spans)
        assertEquals(listOf(1..2, 4..4, 6..7, 8..8), spans)
        assertNull(ctcViterbi(Array(2) { FloatArray(4) { ln(0.25f) } }, intArrayOf(1, 2, 3), 0))   // too few frames
    }

    @Test fun windowsTileTheTimeline() {
        val total = 100L * RATE
        val plan = Chunker.plan(total) { a, b -> (a + b) / 2 }
        assertEquals(0L, plan.first().keepFrom)
        assertEquals(total, plan.last().keepTo)
        for (i in 0 until plan.size - 1) assertEquals(plan[i].keepTo, plan[i + 1].keepFrom)   // no gap, no duplicate
        for (p in plan) assertTrue(p.start <= p.keepFrom && p.keepTo <= p.end && p.end - p.start <= Chunker.MAX)
    }

    @Test fun overlapWordsAreKeptOnce() {
        val a = listOf(w("x", 25_000_000, 25_500_000), w("y", 26_200_000, 26_800_000))
        val b = listOf(w("x", 25_010_000, 25_490_000), w("y", 26_210_000, 26_790_000), w("z", 27_000_000, 27_400_000))
        val merged = Reconcile.keep(a, 0, 26_000_000) + Reconcile.keep(b, 26_000_000, 50_000_000)
        assertEquals(listOf("x", "y", "z"), merged.map { it.text })
    }

    @Test fun monotonicFixesOverlaps() {
        val out = Reconcile.monotonic(listOf(w("a", 0, 10), w("b", 8, 20), w("c", 5, 6)))
        for (i in out.indices) {
            assertTrue(out[i].endUs >= out[i].startUs)
            if (i > 0) assertTrue(out[i - 1].endUs <= out[i].startUs)
        }
    }

    @Test fun wordAtFollowsPlaybackPosition() {
        val ws = listOf(w("Hello", 1_234_567, 1_650_000), w("How", 1_700_000, 1_850_000), w("are", 1_860_000, 2_020_000), w("you?", 2_030_000, 2_450_000))
        assertEquals(-1, Sync.wordAt(ws, 1_000_000))            // before the first word
        assertEquals(0, Sync.wordAt(ws, 1_234_567))             // exactly at a start
        assertEquals(2, Sync.wordAt(ws, 1_860_000))             // tap "are" -> highlighted
        assertEquals(2, Sync.wordAt(ws, 2_025_000))             // short gap: still held
        assertEquals(3, Sync.wordAt(ws, 2_030_000))
        assertEquals(-1, Sync.wordAt(ws, 2_450_000 + 300_000))  // after hold
    }

    @Test fun sentenceAtAndRounding() {
        val s = listOf(Sentence("a", 1_000_000, 2_000_000, emptyList()), Sentence("b", 2_600_000, 4_000_000, emptyList()))
        assertEquals(0, Sync.sentenceAt(s, 2_300_000))          // inside hold window
        assertEquals(1, Sync.sentenceAt(s, 2_600_000))
        assertEquals(-1, Sync.sentenceAt(s, 9_000_000))
        assertEquals(1_861L, 1_860_001L.usToMsCeil())
        assertEquals(1_860L, 1_860_000L.usToMsCeil())
        assertEquals("00:01.860", 1_860_000L.clock())
        assertEquals("1:02:05.400", 3_725_400_000L.clock())
    }

    @Test fun parsesSecondsWithoutFloats() {
        assertEquals(1_234_567L, parseSec6("1.234567"))
        assertEquals(1_860_000L, parseSec6("1.86"))
        assertEquals(2_000_000L, parseSec6(" 2 "))
        assertEquals(1_500_000L, parseSec6("1,5"))
        assertEquals(-1_000_000L, parseSec6("-1"))
        assertNull(parseSec6("1.1234567"))
        assertNull(parseSec6("abc"))
        assertNull(parseSec6(""))
    }

    private val base = listOf(w("a", 0, 1_000_000), w("b", 1_000_000, 2_000_000), w("c", 2_500_000, 3_000_000))

    @Test fun validationRules() {
        fun v(t: String, s: Long, e: Long, max: Long = 0) = Validate.word(base, 1, t, s, e, max)
        assertNull(v("b", 1_100_000, 2_400_000))
        assertNull(v("b", 1_000_000, 2_000_000))                   // unchanged is fine
        assertEquals("Text can't be empty", v(" ", 1_000_000, 2_000_000))
        assertEquals("A word can't contain spaces", v("x y", 1_000_000, 2_000_000))
        assertEquals("Start can't be negative", v("b", -5, 2_000_000))
        assertEquals("End can't be before start", v("b", 1_500_000, 1_400_000))
        assertTrue(v("b", 900_000, 2_000_000)!!.startsWith("Start overlaps"))
        assertTrue(v("b", 1_000_000, 2_600_000)!!.startsWith("End overlaps"))
        assertTrue(Validate.word(base, 2, "c", 2_500_000, 3_000_000, 2_900_000)!!.startsWith("End is past"))
    }

    @Test fun undoRedoAndRevert() {
        val d0 = Doc.of(base)
        val d1 = d0.update(1, "B", 1_100_000, 2_000_000)
        assertEquals("B", d1.words[1].text)
        assertEquals(base, d1.original.words)                              // original stays available
        assertTrue(d1.canUndo && !d1.canRedo)
        assertEquals(base, d1.undo().words)
        assertEquals(d1.words, d1.undo().redo().words)
        assertTrue(d0.update(1, "b", 1_000_000, 2_000_000) === d0)  // no-op edits don't pollute history
        val d2 = d1.update(0, "A", 0, 900_000)
        assertEquals(base, d2.revertAll().words)
        assertEquals(d2.words, d2.revertAll().undo().words)          // revert is undoable
        assertTrue(!d1.undo().update(2, "C", 2_500_000, 3_000_000).canRedo)   // new edit clears redo
        var d = d0
        repeat(Doc.MAX_UNDO + 20) { d = d.update(0, "x$it", 0, 1) }
        assertEquals(Doc.MAX_UNDO, d.past.size)
    }

    @Test fun sentencesAreDerivedFromWords() {
        val ws = listOf(w("Hello", 0, 1), w("there", 1, 2), w("friend", 3, 4))
        assertEquals(1, SentenceGrouper.group(ws).size)
        val edited = ws.toMutableList().also { it[1] = w("there.", 1, 2) }   // punctuation edit splits the sentence
        val s = SentenceGrouper.group(edited)
        assertEquals(listOf("Hello there.", "friend"), s.map { it.text })
        assertEquals(listOf(0, 2), s.map { it.firstIndex })
        assertEquals(3L, s[1].endUs - 0 - 1)                           // times come from the first/last word
    }

    private val five = listOf(w("Hello", 0, 1), w("there", 1, 2), w("friend.", 2, 3), w("next", 3, 4), w("one.", 4, 5))

    @Test fun splitAndMergeKeepWordsAndUndo() {
        val d0 = Doc.of(five)
        assertEquals(listOf("Hello there friend.", "next one."), d0.sentences().map { it.text })
        val sp = d0.splitBefore(1)
        assertEquals(listOf("Hello", "there friend.", "next one."), sp.sentences().map { it.text })
        assertEquals(listOf(0, 1, 3), sp.sentences().map { it.firstIndex })
        assertTrue(sp.splitBefore(1) === sp && d0.splitBefore(3) === d0)            // already a boundary: no-op
        val mg = d0.mergeAfter(2)
        assertEquals(listOf("Hello there friend. next one."), mg.sentences().map { it.text })
        assertEquals(five, mg.words)                                                  // word timestamps untouched
        assertEquals(2, mg.undo().sentences().size)
        assertEquals(2, sp.mergeAfter(0).sentences().size)                            // merge removes a manual split
        assertEquals(0L, mg.sentences()[0].startUs); assertEquals(5L, mg.sentences()[0].endUs)   // derived from first/last word
        assertEquals(2, sp.revertAll().sentences().size)
    }

    @Test fun speakerChangesSplitSentencesAndMergeAdopts() {
        val ws = listOf(Word("a", 0, 1, 0), Word("b", 1, 2, 0), Word("c", 2, 3, 1), Word("d", 3, 4, 1))
        val d = Doc.of(ws)
        assertEquals(listOf("a b", "c d"), d.sentences().map { it.text })
        assertEquals(listOf(0, 1), d.sentences().map { it.speaker })
        val m = d.mergeAfter(1)
        assertEquals(listOf("a b c d"), m.sentences().map { it.text })
        assertTrue(m.words.all { it.speaker == 0 })
        assertEquals(1, d.setSpeaker(0, 1, 1).words[0].speaker)
        assertEquals(listOf(0, 1, 2, 0), listOf(-1, 0, 1, 2).map { d.nextSpeaker(it) })
    }

    @Test fun speakersAssignedByOverlap() {
        val ws = listOf(w("w1", 0, 1_000_000), w("w2", 1_000_000, 2_000_000), w("w3", 2_100_000, 3_000_000), w("w4", 5_000_000, 6_000_000))
        val segs = listOf(SpeakerSegment(0, 1_900_000, 0), SpeakerSegment(1_900_000, 3_500_000, 1))
        assertEquals(listOf(0, 0, 1, 1), Speakers.assign(ws, segs).map { it.speaker })   // w4 inherits
        val lead = Speakers.assign(listOf(w("a", 0, 500_000), w("b", 4_000_000, 5_000_000)), listOf(SpeakerSegment(3_900_000, 5_100_000, 2)))
        assertEquals(listOf(2, 2), lead.map { it.speaker })                            // leading word back-filled
        assertEquals(ws, Speakers.assign(ws, emptyList()))
    }

    @Test fun catalogIsConsistent() {
        assertEquals(Catalog.all.size, Catalog.all.map { it.id }.toSet().size)
        assertTrue(Catalog.all.all { e -> e.files.isNotEmpty() && e.files.all { it.url.startsWith("https://") } })
        for (m in Catalog.asr) assertEquals(listOf("encoder", "decoder", "tokens"), listOf("encoder", "decoder", "tokens").filter { k -> m.files.any { it.localName.contains(k) } })
        assertEquals("align-hi", Catalog.alignerFor("hi")); assertNull(Catalog.alignerFor(""))
    }

    @Test fun speakerNamesFlowIntoExportsAndUndo() {
        val ws = listOf(Word("Hi.", 0, 1_000_000, 0), Word("Yo.", 2_000_000, 3_000_000, 1))
        val d = Doc.of(ws).withNames(mapOf(0 to "Asha", 1 to "S2"))
        assertEquals(mapOf(0 to "Asha"), d.state.names)              // default-looking names are not stored
        assertEquals("Asha", d.label(0)); assertEquals("S2", d.label(1))
        val srt = Exporters.srt(d.toTranscript())
        assertTrue(srt.contains("[Asha] Hi.") && srt.contains("[S2] Yo."))
        assertTrue(d.undo().state.names.isEmpty())
        assertEquals(d.state.names, d.revertAll().state.names)       // revert keeps names
    }

    @Test fun insertAndDeleteWordsKeepIdsMarksAndOriginal() {
        val gap = listOf(w("a", 0, 10), w("b", 20, 30), w("c", 40, 50))
        val d0 = Doc.of(gap)
        val d1 = d0.insertAt(1, "x", 10, 20)
        assertEquals(listOf("a", "x", "b", "c"), d1.words.map { it.text })
        assertNull(d1.original[d1.words[1].id])                         // inserted: no original
        assertEquals(4, d1.words.map { it.id }.toSet().size)            // ids stay unique
        assertTrue(d1.modified)
        assertEquals(gap, d1.delete(1).words)                           // delete restores the original list
        assertTrue(!d1.delete(1).modified)
        assertEquals(gap, d1.revertAll().words)
        assertEquals(d1.words, d1.revertAll().undo().words)
        assertTrue(d1.insertAt(9, "x", 0, 1) === d1)                    // bad index: no-op
        assertTrue(Doc.of(listOf(w("only", 0, 1))).let { it.delete(0) === it })   // last word is kept
        // deleting the last word of a manually split sentence moves the break to the previous word
        val d = Doc.of(five).splitBefore(2)                             // [Hello there] [friend.] [next one.]
        assertEquals(listOf("Hello", "friend.", "next one."), d.delete(1).sentences().map { it.text })
        // marks are keyed by id, so they survive an insert before them
        assertEquals(3, d.insertAt(0, "Oh", 0, 0).sentences().size)
    }

    @Test fun longRecordingSpeakerStitching() {
        val plan = SpeakerStitch.plan(100, 40, 10)
        assertEquals(listOf(0L to 35L, 35L to 65L, 65L to 100L), plan.map { it.keepFrom to it.keepTo })
        assertEquals(listOf(0L, 30L, 60L), plan.map { it.start })
        val known = listOf(SpeakerSegment(0, 10_000_000, 0), SpeakerSegment(10_000_000, 20_000_000, 1))
        val cur = listOf(SpeakerSegment(0, 9_000_000, 5), SpeakerSegment(11_000_000, 20_000_000, 7), SpeakerSegment(25_000_000, 30_000_000, 9))
        val (out, next) = SpeakerStitch.relabel(known, cur, 0, 20_000_000, 2)
        assertEquals(listOf(0, 1, 2), out.map { it.speaker })           // 5->0, 7->1, unmatched 9 -> new id 2
        assertEquals(3, next)
        assertEquals(listOf(SpeakerSegment(5, 8, 0)), SpeakerStitch.clip(listOf(SpeakerSegment(0, 10, 0), SpeakerSegment(20, 30, 1)), 5, 8))
    }

    @Test fun mergeSpeakersInOneStep() {
        val ws = listOf(Word("a.", 0, 1, 0, 0), Word("b.", 2, 3, 1, 1), Word("c.", 4, 5, 2, 2))
        val d = Doc.of(ws).withNames(mapOf(1 to "Bo")).mergeSpeaker(1, 0)
        assertEquals(listOf(0, 0, 2), d.words.map { it.speaker })
        assertTrue(d.state.names.isEmpty())                              // merged speaker's name is dropped
        assertEquals(listOf(0, 1, 2), d.undo().words.map { it.speaker })
        assertTrue(d.mergeSpeaker(0, 0) === d)
    }

    @Test fun longSentencesBecomeSubtitleCues() {
        val words = (0 until 30).map { w("word$it", it * 500_000L, it * 500_000L + 400_000L) }
        val sentences = SentenceGrouper.group(words)
        assertEquals(1, sentences.size)
        val cues = Cues.build(sentences)
        assertTrue(cues.size >= 3)
        assertTrue(cues.all { it.text.replace("\n", " ").length <= Cues.MAX_CHARS })
        assertTrue(cues.all { it.endUs - it.startUs <= Cues.MAX_DURATION_US })
        assertEquals(words.first().startUs, cues.first().startUs)
        assertEquals(words.last().endUs, cues.last().endUs)
        assertEquals(words.joinToString(" ") { it.text }, cues.joinToString(" ") { it.text.replace("\n", " ") })   // no word lost
        assertTrue(Exporters.srt(Transcript(words, sentences)).startsWith("1\n00:00:00,000 --> "))
    }

    @Test fun findAndReplaceInWords() {
        val d = Doc.of(listOf(w("wrld,", 0, 1), w("hello", 2, 3), w("Helo", 4, 5), w(",", 6, 7)))
        assertEquals(listOf(1), d.find("hello"))
        assertEquals(listOf(1, 2), d.find("HEL"))                         // case-insensitive
        assertEquals(emptyList<Int>(), d.find(""))
        val r = d.replaceAll(",", "")
        assertEquals(listOf("wrld", "hello", "Helo", ","), r.words.map { it.text })   // a word that would become empty is kept
        assertEquals(d.words.map { it.startUs }, r.words.map { it.startUs })           // timing untouched
        assertEquals("Hi", d.replaceAll("hello", "Hi").words[1].text)
        assertTrue(d.replaceAll("hello", "two words") === d)              // spaces not allowed
        assertTrue(d.replaceAll("zzz", "x") === d)                        // no match: no history entry
        assertEquals(d.words, d.replaceAll("hello", "Hi").undo().words)
    }

    @Test fun etaRoundsUp() {
        assertEquals(10L, Eta.minutesLeft(60_000, 1, 10))
        assertEquals(3L, Eta.minutesLeft(90_000, 2, 3))          // 135 s left -> 3 min
        assertEquals(0L, Eta.minutesLeft(60_000, 0, 5))
        assertEquals(0L, Eta.minutesLeft(60_000, 4, 0))
    }

    @Test fun incrementalSaveOnlyTouchesChangedWords() {
        val d0 = Doc.of(listOf(w("a", 0, 10), w("b", 20, 30), w("c", 40, 50)))
        assertEquals(emptyList<Int>(), WordDiff.changed(d0.words, d0.words))
        assertEquals(listOf(1), WordDiff.changed(d0.words, d0.update(1, "B", 20, 30).words))
        assertEquals(listOf(0, 2), WordDiff.changed(d0.words, d0.update(0, "A", 0, 10).update(2, "C", 40, 50).words))
        assertNull(WordDiff.changed(d0.words, d0.insertAt(1, "x", 10, 20).words))     // insert: rewrite everything
        assertNull(WordDiff.changed(d0.words, d0.delete(1).words))                     // delete: rewrite everything
    }
}
