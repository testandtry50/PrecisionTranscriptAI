package ai.precisiontranscript.jobs

import ai.precisiontranscript.align.CtcAligner
import ai.precisiontranscript.align.ProportionalAligner
import ai.precisiontranscript.align.WordAligner
import ai.precisiontranscript.asr.SherpaDiarizer
import ai.precisiontranscript.asr.SherpaWhisper
import ai.precisiontranscript.asr.SpeechRecognizer
import ai.precisiontranscript.audio.AudioDecoder
import ai.precisiontranscript.audio.Chunker
import ai.precisiontranscript.audio.PcmFile
import ai.precisiontranscript.audio.RATE
import ai.precisiontranscript.core.Doc
import ai.precisiontranscript.core.Eta
import ai.precisiontranscript.core.Reconcile
import ai.precisiontranscript.core.SpeakerSegment
import ai.precisiontranscript.core.SpeakerStitch
import ai.precisiontranscript.core.Speakers
import ai.precisiontranscript.core.Word
import ai.precisiontranscript.models.Catalog
import ai.precisiontranscript.models.ModelStore
import ai.precisiontranscript.project.ProjectDb
import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

private const val SINGLE_PASS_SAMPLES = 60 * 60 * RATE      // up to here speakers are found on the whole recording at once

/**
 * One transcription job. Everything expensive is checkpointed: the decoded audio stays on disk, and every finished
 * 28-second window is saved to the database. If the app is killed, running the same job again skips finished windows.
 */
class JobRunner(private val ctx: Context, private val db: ProjectDb, private val store: ModelStore) {

    fun pcmFile(id: Long) = File(ctx.filesDir, "jobs/$id.pcm")

    fun discard(id: Long) { pcmFile(id).delete(); db.clearChunks(id) }

    /** Returns the id of the finished project. */
    suspend fun run(spec: JobSpec, onProgress: (String, Float) -> Unit): Long = withContext(Dispatchers.Default) {
        val file = pcmFile(spec.id)
        file.parentFile?.mkdirs()
        if (!db.isDecoded(spec.id) || !file.isFile) {
            db.clearChunks(spec.id)                                   // checkpoints of an earlier decode are meaningless
            onProgress("Extracting audio", 0f)
            AudioDecoder.decode(ctx, Uri.parse(spec.uri), file) { ensureActive(); onProgress("Extracting audio", it) }
            db.markDecoded(spec.id)
        }
        val alignerEntry = if (spec.accurate) Catalog.alignerFor(spec.lang)?.let { Catalog.byId(it) } else null
        val seg = Catalog.byId("seg-pyannote"); val emb = Catalog.byId("emb-titanet")
        val asr = SherpaWhisper(store.dir(Catalog.byId(spec.asrId)), spec.lang)
        try {
            val aligner: WordAligner =
                if (alignerEntry != null) CtcAligner(store.file(alignerEntry, "model.onnx"), store.file(alignerEntry, "vocab.json"))
                else ProportionalAligner()
            try {
                val diarizer = if (spec.speakers) SherpaDiarizer(store.file(seg, "model.onnx"), store.file(emb, "model.onnx")) else null
                try { process(spec, file, asr, aligner, diarizer, onProgress) } finally { diarizer?.close() }
            } finally { aligner.close() }
        } finally { asr.close() }
    }

    private fun CoroutineScope.process(
        spec: JobSpec, file: File, asr: SpeechRecognizer, aligner: WordAligner, diarizer: SherpaDiarizer?,
        onProgress: (String, Float) -> Unit,
    ): Long {
        val warn = ArrayList<String>()
        var segs: List<SpeakerSegment> = emptyList()
        var totalChunks = 0
        PcmFile(file).use { pcm ->
            val plan = Chunker.plan(pcm.samples) { a, b -> Chunker.quietest(pcm, a, b) }    // deterministic, so resuming matches
            totalChunks = plan.size
            val done = db.completedChunks(spec.id)
            var processed = 0
            val t0 = System.currentTimeMillis()
            for ((n, w) in plan.withIndex()) {
                ensureActive()
                if (n in done) continue
                val chunk = pcm.read(w.start, (w.end - w.start).toInt())
                var words: List<Word> = emptyList()
                var approx = false
                if (chunk.any { abs(it.toInt()) >= 300 }) {                                  // silence: avoids Whisper hallucinations
                    val a = aligner.align(chunk, asr.transcribe(chunk))
                    approx = a.approximate
                    val offset = w.start * 1_000_000L / RATE
                    val shifted = a.words.map { it.copy(startUs = it.startUs + offset, endUs = it.endUs + offset) }
                    words = Reconcile.keep(shifted, w.keepFrom * 1_000_000L / RATE, w.keepTo * 1_000_000L / RATE)
                }
                db.saveChunk(spec.id, n, words, approx)
                processed++
                val left = plan.size - done.size - processed
                val eta = Eta.minutesLeft(System.currentTimeMillis() - t0, processed, left)
                onProgress("Recognizing & aligning ${n + 1}/${plan.size}" + (if (left > 0) " · about $eta min left" else ""),
                    (done.size + processed) / plan.size.toFloat())
            }
            if (diarizer != null) {
                ensureActive()
                try {
                    segs = if (pcm.samples <= SINGLE_PASS_SAMPLES) {
                        onProgress("Identifying speakers", 1f)
                        diarizer.diarize(pcm.readFloats())
                    } else diarizeLong(pcm, diarizer, onProgress)
                    if (pcm.samples > SINGLE_PASS_SAMPLES) warn.add("Long recording: speakers were matched across 32-minute windows, so one person may appear as two speakers")
                } catch (e: OutOfMemoryError) {
                    warn.add("Speakers skipped: not enough memory on this phone for this recording")
                }
            }
        }
        onProgress("Saving project", 1f)
        val approxChunks = db.approxChunks(spec.id)
        if (approxChunks > 0) warn.add("$approxChunks of $totalChunks chunks have approximate timing")
        val words = Speakers.assign(Reconcile.monotonic(db.chunkWords(spec.id)), segs)
        val projectId = db.save(null, spec.title, spec.uri, warn, Doc.of(words))
        file.delete()
        db.clearChunks(spec.id)
        return projectId
    }

    /** 32-minute windows with 2 minutes of overlap; speaker labels are matched across windows by overlap. */
    private fun CoroutineScope.diarizeLong(pcm: PcmFile, d: SherpaDiarizer, onProgress: (String, Float) -> Unit): List<SpeakerSegment> {
        val totalUs = pcm.samples * 1_000_000L / RATE
        val plan = SpeakerStitch.plan(totalUs, 32L * 60 * 1_000_000, 2L * 60 * 1_000_000)
        val kept = ArrayList<SpeakerSegment>()
        var prev: List<SpeakerSegment> = emptyList()
        var nextId = 0
        for ((n, w) in plan.withIndex()) {
            ensureActive()
            onProgress("Identifying speakers (${n + 1}/${plan.size})", (n + 1f) / plan.size)
            val raw = d.diarize(pcm.readFloats(w.start * RATE / 1_000_000L, ((w.end - w.start) * RATE / 1_000_000L).toInt()))
                .map { it.copy(startUs = it.startUs + w.start, endUs = it.endUs + w.start) }
            val (cur, nid) = if (n == 0) raw to ((raw.maxOfOrNull { it.speaker } ?: -1) + 1)
                             else SpeakerStitch.relabel(prev, raw, w.start, plan[n - 1].end, nextId)
            nextId = nid; prev = cur
            kept += SpeakerStitch.clip(cur, w.keepFrom, w.keepTo)
        }
        return kept
    }
}
