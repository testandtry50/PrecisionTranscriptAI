package ai.precisiontranscript.core

object Eta {
    /** Minutes left, rounded up, from the average time per finished unit. */
    fun minutesLeft(elapsedMs: Long, processed: Int, left: Int): Long =
        if (processed <= 0 || left <= 0) 0L else (elapsedMs / processed * left + 59_999) / 60_000
}

object WordDiff {
    /** Indices whose word changed, or null if words were inserted, removed or reordered (then everything is rewritten). */
    fun changed(prev: List<Word>, cur: List<Word>): List<Int>? {
        if (prev.size != cur.size) return null
        val out = ArrayList<Int>()
        for (i in cur.indices) {
            if (prev[i].id != cur[i].id) return null
            if (prev[i] != cur[i]) out.add(i)
        }
        return out
    }
}
