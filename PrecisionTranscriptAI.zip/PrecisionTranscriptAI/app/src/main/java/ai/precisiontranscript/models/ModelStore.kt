package ai.precisiontranscript.models

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Models live in the app's private storage and are downloaded once; after that everything runs offline. */
class ModelStore(ctx: Context) {
    private val root = File(ctx.filesDir, "models")

    fun dir(e: ModelEntry) = File(root, e.id)
    fun file(e: ModelEntry, name: String) = File(dir(e), name)
    fun installed(e: ModelEntry) = e.files.all { file(e, it.localName).let { f -> f.isFile && f.length() > 0 } }
    fun delete(e: ModelEntry) = dir(e).deleteRecursively()
    fun sizeBytes(e: ModelEntry): Long = dir(e).walkTopDown().filter { it.isFile }.sumOf { it.length() }

    /** Resumable: an interrupted or cancelled download continues from its .part file (HTTP Range) next time. */
    suspend fun download(e: ModelEntry, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        dir(e).mkdirs()
        e.files.forEachIndexed { idx, rf ->
            val out = file(e, rf.localName)
            if (out.isFile && out.length() > 0) return@forEachIndexed
            val part = file(e, rf.localName + ".part")
            val have = if (part.isFile) part.length() else 0L
            val c = URL(rf.url).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000; c.readTimeout = 30_000; c.instanceFollowRedirects = true
            if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
            try {
                val code = c.responseCode
                if (code == 416) { part.delete(); error("The partial download was invalid. Tap Download again.") }
                check(code == 200 || code == 206) { "HTTP $code for ${rf.localName}" }
                val resumed = code == 206
                val len = c.contentLengthLong
                val total = if (len < 0) 0L else (if (resumed) have else 0L) + len
                c.inputStream.use { input ->
                    FileOutputStream(part, resumed).use { os ->
                        val buf = ByteArray(1 shl 16)
                        var got = if (resumed) have else 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            ensureActive()
                            os.write(buf, 0, n); got += n
                            if (total > 0) onProgress((idx + got.toFloat() / total) / e.files.size)
                        }
                    }
                }
                check(part.renameTo(out)) { "Could not save ${rf.localName}" }
            } finally { c.disconnect() }
        }
        onProgress(1f)
    }
}
