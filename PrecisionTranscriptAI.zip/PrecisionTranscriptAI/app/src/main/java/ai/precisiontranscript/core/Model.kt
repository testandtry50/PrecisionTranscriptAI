package ai.precisiontranscript.core

import java.util.Locale

/** All times are integer microseconds; floats are never used for storage. speaker: -1 = unknown, else 0-based. id: stable per document. */
data class Word(val text: String, val startUs: Long, val endUs: Long, val speaker: Int = -1, val id: Int = 0)

data class Sentence(val text: String, val startUs: Long, val endUs: Long, val words: List<Word>, val firstIndex: Int = 0) {
    val speaker: Int get() = words.firstOrNull()?.speaker ?: -1
}

data class Transcript(
    val words: List<Word>, val sentences: List<Sentence>,
    val warnings: List<String> = emptyList(), val speakerNames: Map<Int, String> = emptyMap(),
)

/** Display name of a speaker: the user's name if set, else "S1", "S2", ...; null when unknown. */
fun speakerLabel(names: Map<Int, String>, speaker: Int): String? = if (speaker < 0) null else names[speaker] ?: "S${speaker + 1}"

/** Microseconds -> "S.ffffff" (six decimals) using integer maths only. */
fun Long.sec6(): String = String.format(Locale.ROOT, "%d.%06d", this / 1_000_000, this % 1_000_000)

object SentenceGrouper {
    private val enders = setOf('.', '?', '!', '…', '।', '॥', '。', '？', '！')
    private val abbreviations = setOf("mr.", "mrs.", "ms.", "dr.", "prof.", "vs.", "e.g.", "i.e.")

    /**
     * Pure function of the words. A sentence ends after sentence-ending punctuation or a long silence (unless
     * the break at that word is in [joins]), after a word whose id is in [cuts], and always where the speaker changes.
     */
    fun group(words: List<Word>, cuts: Set<Int> = emptySet(), joins: Set<Int> = emptySet(), maxGapUs: Long = 2_000_000): List<Sentence> {
        val out = ArrayList<Sentence>()
        var first = 0
        for (i in words.indices) {
            val w = words[i]
            val nxt = words.getOrNull(i + 1)
            val t = w.text.trimEnd('"', '\'', ')', ']', '”', '’')
            val ends = t.isNotEmpty() && t.last() in enders && t.lowercase() !in abbreviations
            val auto = ends || (nxt != null && nxt.startUs - w.endUs >= maxGapUs)
            val brk = nxt == null || w.id in cuts || nxt.speaker != w.speaker || (auto && w.id !in joins)
            if (brk) {
                val ws = words.subList(first, i + 1).toList()
                out.add(Sentence(ws.joinToString(" ") { it.text }, ws.first().startUs, ws.last().endUs, ws, first))
                first = i + 1
            }
        }
        return out
    }
}

object Reconcile {
    /** Chunks overlap, so each word is kept only by the window whose [fromUs, toUs) contains its midpoint. */
    fun keep(words: List<Word>, fromUs: Long, toUs: Long): List<Word> =
        words.filter { val m = (it.startUs + it.endUs) / 2; m >= fromUs && m < toUs }

    /** Guarantees start <= end and non-decreasing order; trims an earlier word that overruns the next word's start. */
    fun monotonic(words: List<Word>): List<Word> {
        val out = ArrayList<Word>(words.size)
        for (w in words) {
            val p = out.lastOrNull()
            var s = w.startUs
            if (p != null) {
                if (s < p.startUs) s = p.startUs
                if (p.endUs > s) out[out.size - 1] = p.copy(endUs = s)
            }
            out.add(w.copy(startUs = s, endUs = maxOf(w.endUs, s)))
        }
        return out
    }
}
