package ai.precisiontranscript.jobs

enum class JobStatus { QUEUED, RUNNING, DONE, FAILED, CANCELLED }

data class JobSpec(
    val id: Long, val uri: String, val title: String, val lang: String,
    val asrId: String, val accurate: Boolean, val speakers: Boolean,
)

data class JobInfo(
    val spec: JobSpec, val status: JobStatus, val stage: String, val progress: Float,
    val error: String, val projectId: Long?,
)
