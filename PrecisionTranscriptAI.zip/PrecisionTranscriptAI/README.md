# Precision Transcript AI 1.0.0

Free, offline speech-to-text for Android with word-level AND sentence-level timestamps (integer microseconds,
shown with six decimals). No paid APIs, no subscriptions, no per-minute charges. Models are downloaded once, then
everything runs on the phone.

## What it does
- Transcribes audio and video (MP3, WAV, M4A, AAC, MP4, MKV...) with Whisper (Tiny, Base, Small, Medium).
- Accurate word timing by CTC forced alignment (English and Hindi); other languages get approximate word timing.
- 19 languages, one-tap AI modes (Fast, Balanced, Best), optional speaker identification.
- Background queue: add many files, they are transcribed one after another in a foreground service, with checkpoints,
  so a 5-hour recording survives the app being closed or killed ("Resume queue").
- Editor: play/pause/stop, 5 s skip, speeds 0.5x-2x, tap a word to play from it, current word and sentence highlighting,
  edit text and timestamps with validation, add and delete words, split and merge sentences, speaker names and merging,
  find and replace, unlimited-style undo/redo, revert to the original transcription.
- Projects autosave to SQLite and reopen from the home screen.
- Export: word JSON, sentence JSON, combined JSON, SRT, VTT (subtitle-sized cues), CSV, TXT.

## Build the APK without a PC (GitHub Actions)
1. Create a GitHub repository. Upload `PrecisionTranscriptAI.zip` to its root (Add file > Upload files).
2. Add file > Create new file, name it `.github/workflows/build.yml`, paste the contents of `build.yml`, commit.
3. Open the Actions tab. "Build APK" starts by itself: it unzips the project, fetches Sherpa-ONNX, builds, runs the tests.
4. When it is green, open Releases > "Latest build" and download `PrecisionTranscriptAI-debug.apk`, then install it.
5. If it is red, open the run > Summary > tap the copy icon on the error box, and send the text.

## Build with Android Studio instead
Open this folder. Copy **all** of `sherpa-onnx/kotlin-api/*.kt` from github.com/k2-fsa/sherpa-onnx (latest release tag) into
`app/src/main/java/com/k2fsa/sherpa/onnx/`, and the Android release's `jniLibs/arm64-v8a/*.so` into
`app/src/main/jniLibs/arm64-v8a/`, then delete `libonnxruntime.so` from that folder (the app uses onnxruntime-android from
Maven). Build > Build APK. `./gradlew testDebugUnitTest` runs the unit tests. The `release` variant is signed with the debug
key so it installs without your own keystore.

## Models (free, downloaded inside the app)
- Speech: Whisper tiny / base / small / medium (sherpa-onnx int8 exports, csukuangfj on Hugging Face)
- Alignment: English wav2vec2-base-960h, Hindi Vakyansh wav2vec2 (community ONNX exports)
- Speakers: pyannote segmentation 3.0 + NeMo TitaNet embeddings
`Catalog.kt` lists every URL. These are third-party repositories; if one disappears, edit its entry.

## Good to know
- Timestamps are exact integers internally, but the audio player seeks in whole milliseconds, and real alignment accuracy
  is limited by the alignment model (about 20 ms), not by the six decimals. SRT and VTT are millisecond formats.
- Recordings over 60 minutes: speakers are matched across 32-minute windows, so one person may occasionally appear as two.
- Android 15 limits data-sync services to about 6 hours a day; the queue then pauses and you tap "Resume queue".
- A 5-hour recording needs about 580 MB of temporary disk space and, on a phone, hours of processing. Fast mode is quickest.
- Not yet tested on a physical device. Seeking in some MP3 files without a seek index may be less precise.
- Not included: saving undo history between sessions, waveform view, a word-alignment model for languages other than Hindi/English.
