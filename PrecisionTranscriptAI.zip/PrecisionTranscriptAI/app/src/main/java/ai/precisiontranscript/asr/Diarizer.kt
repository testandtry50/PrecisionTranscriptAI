package ai.precisiontranscript.asr

import ai.precisiontranscript.core.SpeakerSegment
// Kotlin API files copied from the sherpa-onnx repo (sherpa-onnx/kotlin-api/*.kt), see README.
import com.k2fsa.sherpa.onnx.FastClusteringConfig
import com.k2fsa.sherpa.onnx.OfflineSpeakerDiarization
import com.k2fsa.sherpa.onnx.OfflineSpeakerDiarizationConfig
import com.k2fsa.sherpa.onnx.OfflineSpeakerSegmentationModelConfig
import com.k2fsa.sherpa.onnx.OfflineSpeakerSegmentationPyannoteModelConfig
import com.k2fsa.sherpa.onnx.SpeakerEmbeddingExtractorConfig
import java.io.File

/** "Who spoke when": pyannote segmentation + speaker embeddings + clustering, all on-device. Input: 16 kHz mono floats. */
class SherpaDiarizer(segmentation: File, embedding: File) : AutoCloseable {
    private val sd = OfflineSpeakerDiarization(
        assetManager = null,
        config = OfflineSpeakerDiarizationConfig(
            segmentation = OfflineSpeakerSegmentationModelConfig(
                pyannote = OfflineSpeakerSegmentationPyannoteModelConfig(model = segmentation.path), numThreads = 2),
            embedding = SpeakerEmbeddingExtractorConfig(model = embedding.path, numThreads = 2),
            clustering = FastClusteringConfig(numClusters = -1, threshold = 0.5f),   // number of speakers: automatic
            minDurationOn = 0.3f, minDurationOff = 0.5f,
        ),
    )

    fun diarize(samples: FloatArray): List<SpeakerSegment> = sd.process(samples).map {
        SpeakerSegment((it.start * 1_000_000f).toLong(), (it.end * 1_000_000f).toLong(), it.speaker)
    }

    override fun close() = sd.release()
}
