package ai.precisiontranscript

import ai.precisiontranscript.models.Preset
import android.content.Context

/** Small persisted settings: the last-used transcription choices plus app preferences. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var lang: String
        get() = sp.getString("lang", "hi") ?: "hi"
        set(v) { sp.edit().putString("lang", v).apply() }
    var asrId: String
        get() = sp.getString("asrId", Preset.BALANCED.asrId) ?: Preset.BALANCED.asrId
        set(v) { sp.edit().putString("asrId", v).apply() }
    var accurate: Boolean
        get() = sp.getBoolean("accurate", true)
        set(v) { sp.edit().putBoolean("accurate", v).apply() }
    var speakers: Boolean
        get() = sp.getBoolean("speakers", false)
        set(v) { sp.edit().putBoolean("speakers", v).apply() }
    var preRollMs: Int
        get() = sp.getInt("preRollMs", 0)
        set(v) { sp.edit().putInt("preRollMs", v).apply() }
    var keepAwake: Boolean
        get() = sp.getBoolean("keepAwake", true)
        set(v) { sp.edit().putBoolean("keepAwake", v).apply() }
}
