# Precision Transcript AI

Open in Android Studio -> Build -> Build APK. Not yet compiled or tested on a device.
Run the JVM unit tests with `./gradlew testDebugUnitTest`.

## Build without Android Studio (GitHub Actions)
Push this folder to a GitHub repository (the `.github/workflows/build.yml` file is included). The "Build debug APK" workflow
fetches Sherpa-ONNX, compiles the app, runs the unit tests and uploads the debug APK as an artifact. If it fails, the log shows
the exact compile error. This workflow has not been run yet.

## One-time setup (Android Studio)
**Sherpa-ONNX** (speech recognition + speaker identification): from github.com/k2-fsa/sherpa-onnx copy **all**
`sherpa-onnx/kotlin-api/*.kt` into `app/src/main/java/com/k2fsa/sherpa/onnx/` and the Android release's
`jniLibs/arm64-v8a/*.so` into `app/src/main/jniLibs/arm64-v8a/`.
Both it and onnxruntime-android ship libonnxruntime.so; `pickFirsts` in app/build.gradle.kts resolves that. On a runtime
version error, align the onnxruntime-android version with the one in the sherpa release.
If the Kotlin API parameter names differ from what Recognizer.kt / Diarizer.kt use, match them to those files.

## Models (all free, downloaded inside the app on first use, then fully offline)
- Speech: Whisper tiny / base / small / medium (sherpa-onnx int8 exports, csukuangfj on Hugging Face)
- Word alignment: English wav2vec2-base-960h, Hindi Vakyansh wav2vec2 (community ONNX exports)
- Speakers: pyannote segmentation 3.0 + NeMo TitaNet embeddings
Catalog.kt lists every URL. These are third-party repos; if one disappears, edit its entry.

## Data
Timestamps: integer microseconds everywhere (SQLite INTEGER too), six decimals in the UI and exports.
SRT/VTT are millisecond by format and are built from subtitle cues (<= 2 lines x 42 chars, <= 7 s) cut at word boundaries. Projects autosave to SQLite (current words, original words, splits/merges, speaker names; database v3 migrates older ones); undo history is not saved.
Recordings over 60 min: speakers are identified in 32-minute windows and matched by overlap, so one person can occasionally appear as two speakers.

## Not built yet
Saving undo history between sessions (needs a diff-based history), waveform view, find/replace, a background service for very long jobs, per-word confidence, alignment models for languages other than Hindi/English.

## Long recordings and the background queue
- Add several files at once; they are transcribed one after another in a foreground service (notification, wake lock),
  so the queue keeps running with the screen off or the app closed. Open finished projects from the Queue or Recent projects.
- Every finished 28-second window is checkpointed in SQLite and the decoded audio stays on disk, so if Android kills the app
  the job resumes where it stopped (tap "Resume queue"). Decoded audio takes about 115 MB per hour (about 580 MB for 5 hours)
  until the job finishes; the speaker stage restarts from its beginning if interrupted.
- Android 15 limits data-sync services to about 6 hours a day; the queue then pauses and resumes from the app.
- Autosave writes only the words that changed, so editing a 5-hour transcript (~45,000 words) stays fast.
- How long 5 hours takes depends on the phone and model: use Fast (Whisper Base) for the quickest run, keep the phone charging.

## Settings
Tap pre-roll, keep-screen-on, model storage and deletion. Last-used language / AI mode / speaker choices are remembered. Downloads resume after interruption.
