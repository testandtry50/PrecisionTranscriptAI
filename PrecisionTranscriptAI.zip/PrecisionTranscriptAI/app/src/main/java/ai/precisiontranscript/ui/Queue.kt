package ai.precisiontranscript.ui

import ai.precisiontranscript.jobs.JobInfo
import ai.precisiontranscript.jobs.JobStatus
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun JobRow(j: JobInfo, onCancel: () -> Unit, onRemove: () -> Unit, onRetry: () -> Unit, onOpen: () -> Unit) {
    val active = j.status == JobStatus.QUEUED || j.status == JobStatus.RUNNING
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(j.spec.title, maxLines = 1)
        Text(
            j.status.name.lowercase() + " · " + j.stage + (if (j.error.isNotEmpty()) " · " + j.error else ""),
            style = MaterialTheme.typography.labelSmall,
            color = if (j.status == JobStatus.FAILED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
        )
        if (active) LinearProgressIndicator(progress = { j.progress }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (j.status == JobStatus.DONE && j.projectId != null) TextButton(onClick = onOpen) { Text("Open") }
            if (j.status == JobStatus.FAILED || j.status == JobStatus.CANCELLED) TextButton(onClick = onRetry) { Text("Retry") }
            if (active) TextButton(onClick = onCancel) { Text("Cancel") } else TextButton(onClick = onRemove) { Text("Remove") }
        }
    }
}
